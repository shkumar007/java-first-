﻿INSERT INTO frukart.usersdata (username,"password",email,mobile) VALUES 
('onkar','onkar','onkar@gmail.com','9739712341')
,('mahith','mahith','rajmahithreddy@gmail.com','7013127741')
,('rajamouli','raja','raja@gmail.com','123456789')
,('hari','123456','hari@gmail.com','123456789')
,('ravi','1234','ravi1@gmail.com','134156')
,('kirthika','12345','kirthikajankarajan@gmail.com','8675086363')
,('Hemanth','1234564','shkumar.1993@gmail.com','132456879')
,('Hemanth','1234564','shkumar.1993@gmail.com','132456879')
;