package com.regnant.frukart.dao;

public class SqlConstants {

}
