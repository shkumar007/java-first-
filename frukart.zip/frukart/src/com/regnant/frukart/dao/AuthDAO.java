package com.regnant.frukart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AuthDAO {

	public static boolean signIn(String email, String password) throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select \"password\" from frukart.usersdata where email='" + email + "';");
		System.out.println(password + email);
		String p = "";
		while (rs.next()) {
			p = rs.getString(1);
		}
		System.out.println(p);
		if (p.equals(password)) {
			return true;
		} else {
			return false;
		}
	}
	
	
	public static String getMailID(String mail) throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		PreparedStatement stmt = con.prepareStatement("select email from frukart.usersdata where email = ?");
		stmt.setString(1, mail);
		String mailID = null;
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			mailID = rs.getString(1);
		}
		return mailID;
	}
	
	public static String getForgottenPassword(String name) throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		PreparedStatement stmt = con.prepareStatement("select password from frukart.usersdata where email = ?");
		stmt.setString(1, name);
		String password = null;
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			password = rs.getString(1);
		}

		return password;
	}

}
