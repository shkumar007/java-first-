package com.regnant.frukart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.regnant.frukart.beans.ProductBean;

public class ProductDAO {

	public static List<ProductBean> getProducts() throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from frukart.productdetails");
		List<ProductBean> fruits = new ArrayList<>();
		while (rs.next()) {
			String fid = rs.getString(1);
			String pic = rs.getString(2);
			String price = rs.getString(3);
			String fname = rs.getString(4);
			String specfication = rs.getString(5);
			
			ProductBean productBean = new ProductBean(fid,fname,specfication,price,pic);
			fruits.add(productBean);
		}
		return fruits;
	}

	public static Map<String, String> getProductById(String id) throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		PreparedStatement stmt = con.prepareStatement("select * from frukart.productdetails where fid=?");
		stmt.setString(1, id);
		ResultSet rs = stmt.executeQuery();
		Map<String, String> fruit = new HashMap<>();
		while (rs.next()) {
			String fid = rs.getString(1);
			String pic = rs.getString(2);
			String price = rs.getString(3);
			String fname = rs.getString(4);
			String specfication = rs.getString(5);

			fruit.put("id", fid);
			fruit.put("name", fname);
			fruit.put("pic", pic);
			fruit.put("price", price);
			fruit.put("about", specfication);
		}
		return fruit;
	}

}
