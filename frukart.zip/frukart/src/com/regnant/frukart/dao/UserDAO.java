package com.regnant.frukart.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UserDAO {

	public static void registration(String username, String password, String email, String phone) throws SQLException {

		try {
			Connection con = DbConnection.getConnection();
			PreparedStatement pstmt = con.prepareStatement("insert into frukart.usersdata values(?,?,?,?)");
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			pstmt.setString(3, email);
			pstmt.setString(4, phone);
			pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}

	}

	
}
