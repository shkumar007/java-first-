package com.regnant.frukart.listners;

import java.util.Map;
import java.util.Set;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * Application Lifecycle Listener implementation class SessionInvalidateListener
 *
 */
@WebListener
public class SessionInvalidateListener implements HttpSessionListener {

    /**
     * Default constructor. 
     */
    public SessionInvalidateListener() {
        // TODO Auto-generated constructor stub
    	System.out.println("SessionInvalidateListener.SessionInvalidateListener()");
    }

	/**
     * @see HttpSessionListener#sessionCreated(HttpSessionEvent)
     */
    public void sessionCreated(HttpSessionEvent se)  { 
         // TODO Auto-generated method stub
    	System.out.println("SessionInvalidateListener.sessionCreated()");
    }

	/**
     * @see HttpSessionListener#sessionDestroyed(HttpSessionEvent)
     */
    @SuppressWarnings("unlikely-arg-type")
	public void sessionDestroyed(HttpSessionEvent se)  {
    	System.out.println("SessionInvalidateListener.sessionDestroyed()");
         // TODO Auto-generated method stub
    	HttpSession session = se.getSession();
    	Set<Map<String, String>> addedProducts =(Set<Map<String, String>>) session.getAttribute("addproducts");
    	addedProducts.stream().forEach((productMap)->{
    		System.out.println("Store Product while destroying->");
    		productMap.entrySet().stream().forEach((entry)->{
    			System.out.print(entry.getKey() + "=" + entry.getValue() + " ");
    		});
    	});
    	
    }
	
}
