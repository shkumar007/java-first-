package com.regnant.frukart.utils;

public class Constants {
	
	public static final String HOME_PAGE = "home";
	public static final String PASSWORD = "password";
	public static final String EMAIL = "email";
	public static final String FRUITS_LIST = "fruitsList";
}
