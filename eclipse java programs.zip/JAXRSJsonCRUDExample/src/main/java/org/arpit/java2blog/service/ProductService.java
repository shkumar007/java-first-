package org.arpit.java2blog.service;

import java.sql.SQLException;
import java.util.List;

import org.arpit.java2blog.bean.ProductBean;
import org.arpit.java2blog.dao.ProductDAO;



public class ProductService {

	public ProductBean getProduct(int productId) throws ClassNotFoundException, SQLException {
		ProductBean pb = ProductDAO.getProductById(productId);
		
		
		return pb;
	}
	
	public List<ProductBean> getAllProducts() throws ClassNotFoundException, SQLException{
		List<ProductBean> products = ProductDAO.getProducts();
		return products;
	}
}
