package org.arpit.java2blog.bean;

public class ProductBean {
	
	private String fid;
	private String fname;
	private String specification;
	private String price;
	private String pic;
	public ProductBean(String fid, String fname, String specification, String price, String pic) {
		this.fid = fid;
		this.fname = fname;
		this.specification = specification;
		this.price = price;
		this.pic = pic;
	}
	public String getFid() {
		return fid;
	}
	public void setFid(String fid) {
		this.fid = fid;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getSpecification() {
		return specification;
	}
	public void setSpecification(String specification) {
		this.specification = specification;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	
}
