package org.arpit.java2blog.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.arpit.java2blog.bean.userbean;


public class userdao {

	
	public static void registration(userbean us) throws SQLException, ClassNotFoundException {

	Connection con = ProductDAO.getConnection();
		try {
			System.out.println(us.getEmailId());
			PreparedStatement pstmt = con.prepareStatement("insert into ordergrains.usersdata values(?,?,?,?)");
			pstmt.setString(1, us.getName());
			pstmt.setString(2, us.getPwd());
			pstmt.setString(3, us.getName());
			pstmt.setString(4, us.getPhoneNum());
			pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
		finally {
			con.close();
		}

	}
	
}
