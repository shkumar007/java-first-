package org.arpit.java2blog.controller;

import java.sql.SQLException;
import java.util.List;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.arpit.java2blog.bean.Country;
import org.arpit.java2blog.bean.userbean;
import org.arpit.java2blog.service.signupservice;

@Path("/login")

public class login {

	
	signupservice signupservice123=new signupservice();
	
//    @GET
//    @Produces(MediaType.APPLICATION_JSON)
//	public List<Country> getCountries()
//	{
//		
//		List<Country> listOfCountries=loginservice123.getAllCountries();
//		return listOfCountries;
//	}
//
//    @GET
//    @Path("/{id}")
//    @Produces(MediaType.APPLICATION_JSON)
//	public Country getCountryById(@PathParam("id") int id)
//	{
//		return loginservice123.getCountry(id);
//	}
   
    @POST
    @Produces(MediaType.APPLICATION_JSON)
	public void addCountry(userbean user1) throws ClassNotFoundException, SQLException
	{
    	
		signupservice123.adduser(user1);
	}
//
//    @PUT
//    @Produces(MediaType.APPLICATION_JSON)
//	public Country updateCountry(Country country)
//	{
//		return loginservice123.updateCountry(country);
//		
//	}
//	
//    @DELETE
//    @Path("/{id}")
//    @Produces(MediaType.APPLICATION_JSON)
//	public void deleteCountry(@PathParam("id") int id)
//	{
//    	loginservice123.deleteCountry(id);
//		
//	}
	
	
	
	
	
}
