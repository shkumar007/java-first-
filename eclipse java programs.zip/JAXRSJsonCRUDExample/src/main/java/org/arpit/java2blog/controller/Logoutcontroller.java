package org.arpit.java2blog.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import org.arpit.java2blog.bean.loginbean;


@Path("/logout")
public class Logoutcontroller {

	 @GET
	    @Produces(MediaType.APPLICATION_JSON)
		public void logoutcontroller(loginbean user, @Context HttpServletRequest request)
		{
		 HttpSession session = request.getSession();
		
		 if (session != null) {
				session.invalidate();
			}
		 
		 
		 
		}

	
	 

	
	 
	 
	 
	 
	 
	 
}
