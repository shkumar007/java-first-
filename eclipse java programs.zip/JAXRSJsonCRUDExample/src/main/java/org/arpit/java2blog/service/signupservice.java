package org.arpit.java2blog.service;

import java.sql.SQLException;

import org.arpit.java2blog.bean.Country;
import org.arpit.java2blog.bean.userbean;
import org.arpit.java2blog.dao.userdao;

public class signupservice {

	public void adduser(userbean user1) throws ClassNotFoundException, SQLException {
		
		userdao.registration(user1);
		
		
	}

}
