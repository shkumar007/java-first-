package org.arpit.java2blog.bean;

public class userbean {

	private String name;
	private String pwd;
	private String phoneNum;
	private String emailId;
	public userbean(String name, String pwd, String phoneNum, String emailId) {
		this.name = name;
		this.pwd = pwd;
		this.phoneNum = phoneNum;
		this.emailId = emailId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
}
