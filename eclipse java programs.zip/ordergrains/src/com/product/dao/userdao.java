package com.product.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class userdao {

	public static boolean registration(String username, String password, String email, String phone)
			throws SQLException, ClassNotFoundException {

		
		
		
		Connection con = DbConnection.getConnection();
		try {
			PreparedStatement pstmt = con.prepareStatement("insert into ordergrains.userdata values(?,?,?,?)");
			pstmt.setString(1, username);
			pstmt.setString(2, password);
			pstmt.setString(3, email);
			pstmt.setString(4, phone);
			pstmt.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			con.close();
		}
		return true;
		

	}
	
	
	
	
	public static boolean signIn(String email, String password) throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select \"password\" from ordergrains.usersdata where email='" + email + "';");
		System.out.println(password + email);
		String p = "";
		while (rs.next()) {
			p = rs.getString(1);
		}
		System.out.println(p);
		con.close();
		if (p.equals(password)) {
			return true;
		} else {
			return false;
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
