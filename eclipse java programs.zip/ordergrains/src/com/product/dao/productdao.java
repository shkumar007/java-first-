package com.product.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.regnant.beans.productbeans;

public class productdao {

	public static List<productbeans> getProducts() throws ClassNotFoundException, SQLException {
		Connection con = DbConnection.getConnection();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from ordergrains.productdetails");
		List<productbeans> grainslist = new ArrayList<>();
		while (rs.next()) {
			String fid = rs.getString(1);
			String pic = rs.getString(2);
			String price = rs.getString(3);
			String fname = rs.getString(4);
			String specfication = rs.getString(5);

			productbeans productBean = new productbeans(fid, fname, specfication, price, pic);
			grainslist.add(productBean);
		}

		con.close();
		System.out.println(grainslist);
		return grainslist;
	}

}
