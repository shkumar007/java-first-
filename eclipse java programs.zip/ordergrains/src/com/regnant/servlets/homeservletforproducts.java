package com.regnant.servlets;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.product.dao.productdao;
import com.regnant.beans.productbeans;
import com.regnant.utils.constants;

/**
 * Servlet implementation class homeservletforproducts
 */
@WebServlet("/homeservletforproducts")
public class homeservletforproducts extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public homeservletforproducts() {
		super();
		// TODO Auto-generated constructor stub


	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			List<productbeans> productsList = productdao.getProducts();
			request.setAttribute(constants.GRAINS_LIST, productsList);
			
			Gson gsonBuilder = new GsonBuilder().create();
			String jsonFromJavaArrayList = gsonBuilder.toJson(productsList);
			
			response.getWriter().write(jsonFromJavaArrayList);
			
			
//			RequestDispatcher rd = request.getRequestDispatcher("/view/home.jsp");
//			rd.forward(request, response);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
//		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
