package com.regnant.servlets;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.product.dao.userdao;
import com.regnant.utils.constants;

/**
 * Servlet implementation class loginservlet
 */
@WebServlet("/loginservlet")
public class loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());

	
	
		String email = request.getParameter(constants.EMAIL);
		String password = request.getParameter(constants.PASSWORD);
		boolean output = false;
		try {
			output = userdao.signIn(email, password);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (output) {
			HttpSession session = request.getSession();
			session.setAttribute(constants.EMAIL, email);
			
			response.getWriter().write("login sucess");
			
			
//			response.sendRedirect("home");
//			RequestDispatcher rd = request.getRequestDispatcher("home");
//			rd.forward(request, response);
		} else {
			response.getWriter().write("wrong credentials");
//			RequestDispatcher rd = request.getRequestDispatcher("/view/wrongpassword.jsp");
//			rd.forward(request, response);
		}


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
