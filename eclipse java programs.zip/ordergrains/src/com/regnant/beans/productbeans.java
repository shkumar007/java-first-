package com.regnant.beans;

public class productbeans {


	private String id;
	private String name;
	private String details;
	private String price;
	private String img;
	

	public productbeans(String id, String name, String details, String price, String img) {
		this.id = id;
		this.name = name;
		this.details = details;
		this.price = price;
		this.img = img;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
}
