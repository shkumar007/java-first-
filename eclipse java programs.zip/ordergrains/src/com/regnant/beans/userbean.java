package com.regnant.beans;

public class userbean {
	private String username;
	private String userpassword;
	private String userphonenumber;
	private String usermailId;
	public userbean(String username, String userpassword, String userphonenumber, String usermailId) {
		this.username = username;
		this.userpassword = userpassword;
		this.userphonenumber = userphonenumber;
		this.usermailId = usermailId;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserpassword() {
		return userpassword;
	}
	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}
	public String getUserphonenumber() {
		return userphonenumber;
	}
	public void setUserphonenumber(String userphonenumber) {
		this.userphonenumber = userphonenumber;
	}
	public String getUsermailId() {
		return usermailId;
	}
	public void setUsermailId(String usermailId) {
		this.usermailId = usermailId;
	}
	
	
	
	
	
}
