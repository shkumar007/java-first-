package jdbc;

public class StudentTempClass {

	private int id;
	private String name;
	private int phoone_number;
	private String mailid;

	public StudentTempClass(int id, String name, int phoone_number, String mailid) {
		this.id = id;
		this.name = name;
		this.phoone_number = phoone_number;
		this.mailid = mailid;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPhoone_number() {
		return phoone_number;
	}

	public void setPhoone_number(int phoone_number) {
		this.phoone_number = phoone_number;
	}

	public String getMailid() {
		return mailid;
	}

	public void setMailid(String mailid) {
		this.mailid = mailid;
	}

	@Override
	public String toString() {
		return "{" + this.id + "," + this.name + "," + this.phoone_number + "," + this.mailid + "}";
	}

}
