package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Jdbcconnection {
	public static void main(String args[]) throws SQLException, ClassNotFoundException {
		Class.forName("org.postgresql.Driver");
		Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/java", "postgres", "123456");
		PreparedStatement pstmt = null;

		while (true) {

			Scanner sc = new Scanner(System.in);
			System.out.println("pls select option : ");
			System.out.println("1.enter data");
			System.out.println("2.update data");
			System.out.println("3.delete data");
			System.out.println("4.displyaa");
			System.out.println("5.terminate");
			System.out.println("Enter your choice:");
			int n;
			try {
				n = sc.nextInt();

				switch (n) {
				case 1:

					System.out.println("please enter id");
					int id = sc.nextInt();
					System.out.println("please enter name");
					String name = sc.next();
					System.out.println("please enter phone");
					int phone = sc.nextInt();
					System.out.println("please enter mail");
					String email = sc.next();
					addemployee(id, name, phone, email, conn, pstmt);
					break;
				case 2:
					System.out.println("please enter id");
					int id1 = sc.nextInt();
					System.out.println("please enter name");
					String na = sc.next();
					updateemployee(id1, conn, pstmt, na);
					break;
				case 3:
					System.out.println("please enter id");
					int id2 = sc.nextInt();
					deleteemployee(id2, conn, pstmt);
					break;
				case 4:
					displayAll(conn, pstmt);
					break;
				case 5:
					sc.close();
					conn.close();
					System.exit(0);

				}
			} catch (Exception e) {
				System.out.println("InputMismatch");
			}

		}
		
		

	}

	public static void addemployee(int id, String name, int phonenum, String mailid, Connection conn,
			PreparedStatement pstmt) throws SQLException {
		pstmt = conn.prepareStatement("insert into employee.emp values(?,?,?,?)");
		pstmt.setInt(1, id);
		pstmt.setString(2, name);
		pstmt.setInt(3, phonenum);
		pstmt.setString(4, mailid);
		pstmt.executeUpdate();
	}

	public static void updateemployee(int id, Connection conn, PreparedStatement pstmt, String name)
			throws SQLException {

		pstmt = conn.prepareStatement("update employee.emp set name = ? where id= ?");
		pstmt.setString(1, name);
		pstmt.setInt(2, id);
		pstmt.executeUpdate();

	}

	/**
	 * @param id
	 * @param conn
	 * @param pstmt
	 * @throws SQLException
	 */
	public static void deleteemployee(int id, Connection conn, PreparedStatement pstmt) throws SQLException {
		pstmt = conn.prepareStatement("delete from employee.emp where id=" + id);
		pstmt.executeUpdate();

	}

	public static void displayAll(Connection conn, PreparedStatement pstmt) throws SQLException {
		Statement stmt = conn.createStatement();
		String sql = "select * from employee.emp";
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next())
			System.out.println(
					rs.getInt(1) + "     " + rs.getString(2) + "     " + rs.getInt(3) + "   " + rs.getString(4));
	}
	
	public static void change_data_type(Connection conn, PreparedStatement pstmt) throws SQLException {
		Statement stmt=conn.createStatement();
		String query = "ALTER TABLE employee.emp MODIFY `id' varchar(20)";
		
		ResultSet rs=stmt.executeQuery(query);
		
	}
	
	

}