package jdbc;

import java.util.List;

public class CountryAndState {

	private int countryid;
	private String countryname;

	private List<String> statename;

	

	public CountryAndState(int countryid, String countryname, List<String> statename) {
		this.countryid = countryid;
		this.countryname = countryname;
		this.statename = statename;
	}



	public int getCountryid() {
		return countryid;
	}



	public void setCountryid(int countryid) {
		this.countryid = countryid;
	}



	public String getCountryname() {
		return countryname;
	}



	public void setCountryname(String countryname) {
		this.countryname = countryname;
	}



	public List<String> getStatename() {
		return statename;
	}



	public void setStatename(List<String> statename) {
		this.statename = statename;
	}



	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "{" + this.countryid + "," + this.countryname + "," +  this.statename + "}";
	}

}
