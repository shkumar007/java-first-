package jdbc;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AddingStudentToMap {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {

		@SuppressWarnings("unused")
		StudentTempClass obj1 = null;
		List<HashMap<String, String>> MainList = new ArrayList<>();

		Class.forName("org.postgresql.Driver");

		Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/java", "postgres", "123456");
		Statement stmt = conn.createStatement();

		String sql = "select * from employee.emp";

		/***
		 * Finding Schemas Present in Database
		 */
		DatabaseMetaData obj = conn.getMetaData();

		System.out.println("DRIVER Name    " + obj.getDriverName());
		System.out.println("Driver Version   " + obj.getDriverVersion());
		System.out.println("USER NAME   " + obj.getUserName());
		System.out.println("PRODUCT NAME " + obj.getDatabaseProductName());
		System.out.println("------------------------------------------------------------------------------");
		System.out.println("SCHEMAS PRESENT IN DATA BASE ARE : ");
		ResultSet kkk = obj.getSchemas();
		while (kkk.next()) {
			String Schema = kkk.getString(1);

			System.out.println(Schema);
		}
		System.out.println("-------------------------------------------------------");
		/***
		 * Finding data present in Table
		 */
		System.out.println("RESULT SET META DATA ARE : ");

		ResultSet rs = stmt.executeQuery(sql);

		ResultSetMetaData rsmd = rs.getMetaData();
		int colcount = rsmd.getColumnCount();
		System.out.println(colcount);

		String tablename = rsmd.getTableName(colcount);

		System.out.println(tablename);

		for (int i = 1; i <= colcount; i++) {

			String col_name = rsmd.getColumnName(i);

			String col_type = rsmd.getColumnTypeName(i);

			System.out.println(col_name + "---------" + col_type);

		}
		System.out.println("--------------------------------------------------------------------");
		while (rs.next()) {
			String id = "" + rs.getInt(1);
			String name = rs.getString(2);
			String phonenumber = "" + rs.getInt(3);
			String mail = rs.getString(4);
			HashMap<String, String> hm2 = new HashMap<>();
			hm2.put("id", id);
			hm2.put("phne", phonenumber);
			hm2.put("name", name);
			hm2.put("mail", mail);
			MainList.add(hm2);

		}

		conn.close();
		stmt.close();

		for (HashMap<String, String> kk : MainList) {
			for (Map.Entry<String, String> aa : kk.entrySet())
				System.out.println(aa.getKey() + "----" + aa.getValue());

		}
	}

}
