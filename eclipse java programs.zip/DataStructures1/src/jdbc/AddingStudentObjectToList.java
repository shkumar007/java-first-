package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AddingStudentObjectToList {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		StudentTempClass obj1 = null;
		List<StudentTempClass> li = new ArrayList<>();
		Connection conn = connection();
		Statement stmt = conn.createStatement();
		String sql = "select * from employee.emp";
		ResultSet rs = stmt.executeQuery(sql);

		ResultSetMetaData rsmd = rs.getMetaData();
		int colcount = rsmd.getColumnCount();
		System.out.println(colcount);
		String tablename = rsmd.getTableName(colcount);
		System.out.println(tablename);

		for (int i = 1; i <= colcount; i++) {

			String col_name = rsmd.getColumnName(i);

			String schemaname = rsmd.getSchemaName(i);

			String col_type = rsmd.getColumnTypeName(i);

			System.out.println(col_name + "lllllllll" + col_type + "*********" + schemaname);

		}

		while (rs.next()) {
			int id = rs.getInt(1);
			String name = rs.getString(2);
			int phonenumber = rs.getInt(3);
			String mail = rs.getString(4);

			obj1 = new StudentTempClass(id, name, phonenumber, mail);
			li.add(obj1);

		}

		conn.close();
		stmt.close();

		for (Iterator<StudentTempClass> iterator = li.iterator(); iterator.hasNext();) {
			StudentTempClass studentTempClass = (StudentTempClass) iterator.next();
			System.out.println(studentTempClass);
		}

	}

	public static Connection connection() throws ClassNotFoundException, SQLException {
		Class.forName("org.postgresql.Driver");
		Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/java", "postgres", "123456");
		return conn;
	}

}
