package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DatabaseConnection {
public static void getconnection(String name,String phonenum,String mailid) throws ClassNotFoundException, SQLException {
		Class.forName("org.postgresql.Driver");
		Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/java", "postgres", "123456");
		PreparedStatement	pstmt = conn.prepareStatement("insert into frukart.userfrukart values(?,?,?)");
		pstmt.setString(1,name);
		pstmt.setString(2, phonenum);
		pstmt.setString(3, mailid);
		pstmt.executeUpdate();
		 
	}
	
}
