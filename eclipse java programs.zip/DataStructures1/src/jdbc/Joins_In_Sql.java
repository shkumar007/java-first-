package jdbc;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

public class Joins_In_Sql {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {

		CountryAndState obj = null;
		Connection conn = databaseconnection();
		Scanner sc = new Scanner(System.in);
		System.out.println("pls enter the country name\n1.India\n2.nepal\n3.srilanka\n4.china");
		String str = sc.next().toLowerCase();
		
		
		sc.close();
		
		
		
		
		List<CountryAndState> stateslist = new ArrayList<>();
		List<String> st = new ArrayList<>();
		Statement stmt = conn.createStatement();
		String sql = "select * from employee.country left join employee.state on employee.country.countryid=employee.state.countryid where countryname='"
				+ str + "';";
		ResultSet rs = stmt.executeQuery(sql);
		while (rs.next()) {

			int countryid = rs.getInt(1);
			String countryname = rs.getString(2);
			String statename = rs.getString(5);
			st.add(statename);
			obj = new CountryAndState(countryid, countryname, st);
		}
		stateslist.add(obj);
		conn.close();
		stmt.close();

		for (Iterator iterator = stateslist.iterator(); iterator.hasNext();) {
			CountryAndState countryAndState = (CountryAndState) iterator.next();

			System.out.println(countryAndState);

		}

	}

	public static Connection databaseconnection()
			throws FileNotFoundException, IOException, ClassNotFoundException, SQLException {
		FileReader fr = new FileReader("dbprop.properties");
		Properties p = new Properties();
		p.load(fr);

		Class.forName("org.postgresql.Driver");
		Connection conn = DriverManager.getConnection("jdbc:postgresql://localhost:5432/java", p.getProperty("user"),
				p.getProperty("password"));
		return conn;
	}

}
