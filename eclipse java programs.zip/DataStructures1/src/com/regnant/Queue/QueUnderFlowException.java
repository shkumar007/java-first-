package com.regnant.Queue;

public class QueUnderFlowException  extends Exception{
public QueUnderFlowException() {
	System.out.println("Hi Boss Queue is already Empty");
}
}
