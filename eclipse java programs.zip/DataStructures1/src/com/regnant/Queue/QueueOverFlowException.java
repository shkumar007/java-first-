package com.regnant.Queue;

public class QueueOverFlowException extends Exception {
public QueueOverFlowException() {
	System.out.println("Hi Boss Queue is overflow");
}
}
