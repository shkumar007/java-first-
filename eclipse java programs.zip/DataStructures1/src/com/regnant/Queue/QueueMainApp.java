package com.regnant.Queue;



public class QueueMainApp {

	public static void main(String[] args) throws QueueOverFlowException, QueUnderFlowException {
		
		Queue obj=new Queue();
		obj.push(1);
		obj.push(2);
		obj.push(3);
		obj.push(4);
		obj.push(5);
//		obj.push(6);
		obj.pop();
		obj.pop();
		obj.pop();
		obj.pop();
		obj.pop();
		obj.pop();
//		//obj.push(99);
		
		obj.show();
	}

}
