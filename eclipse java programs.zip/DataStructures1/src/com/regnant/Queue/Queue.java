package com.regnant.Queue;

public class Queue {
	int array[] = new int[5];
	int size;
	int frontindex;
	int cursor;

	public void push(int data) throws QueueOverFlowException {
		if (cursor < array.length) {
			array[cursor] = data;
			cursor = cursor + 1;
			size = size + 1;
		} else {
			throw new QueueOverFlowException();
		}
	}

	public void pop() throws QueUnderFlowException {
		int data = 0;
		if (array[frontindex] > 0) {
			data = array[frontindex];
			frontindex = frontindex + 1;
			size = size - 1;
		} else {
			throw new QueUnderFlowException();
		}
	}

	public void show() {
		for (int i : array) {
			System.out.print(i + " ");
		}
		System.out.println(" are entered elements");
		for (int i = 0; i < size; i++) {
			System.out.print(array[frontindex + i] + " ");
		}
	}
}
