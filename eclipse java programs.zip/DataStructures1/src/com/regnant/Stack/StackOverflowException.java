package com.regnant.Stack;

public class StackOverflowException extends Exception{
public StackOverflowException() {
	System.out.println("Hi Boss Stack is Overflow ");
}
}
