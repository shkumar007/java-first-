package com.regnant.Stack;

public class StackUnderflowException extends Exception {

	
	public StackUnderflowException() {
		System.out.println("Hello Boss Stack is already Empty");
	}
}
