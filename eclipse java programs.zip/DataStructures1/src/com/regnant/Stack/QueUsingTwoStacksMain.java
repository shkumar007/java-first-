package com.regnant.Stack;

import java.util.Scanner;
import java.util.Stack;

public class QueUsingTwoStacksMain {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		Stack<Integer> s1 = new Stack<>();
		Stack<Integer> s2 = new Stack<>();

		System.out.println(s1);
		System.out.println(s2);

		while (true) {
			System.out.println("pls enter option \n 1 :: push \n 2 :: pop");

			int x = sc.nextInt();
			switch (x) {

			case 1:
				System.out.println("pls enter number to input");
				int m = sc.nextInt();

				int siz1 = s2.size();
				for (int i = 0; i < siz1; i++) {
					s1.push(s2.pop());
				}
				s1.push(m);

				System.out.println(s1);
				break;
			case 2:
				int siz = s1.size();
				for (int i = 0; i < siz; i++) {
					s2.push(s1.pop());
				}

				System.out.println("popped element is : " + s2.pop());
				break;
			}

		}
	}

}
