package com.regnant.Stack;

public class FindingLargestPalindromeInAstring {

	public static void main(String[] args) {
		String str = "maamhowareyoumadam";
		palstring(str);
	}

	static void palstring(String str) {
		String sub = null;
		int start = 0;
		int length_of_string = str.length();

		for (int i = 0; i < length_of_string; i++) {
			char ch1 = str.charAt(start);
			char ch2 = str.charAt(i);
			System.out.println(ch1 + "     " + ch2);
			if (ch1 == ch2) {
				sub = str.substring(start, i+1);
				System.out.println(sub);
			}

		}
		if (palindrome(sub)) {
			System.out.println("biggest palindrome is : " + sub);
			start++;
		}

	}

	static boolean palindrome(String str) {

		StringBuffer sb = new StringBuffer(str);
		String after_reverse = sb.reverse() + "";

		if (str.equals(after_reverse)) {
			return true;
		} else {

			return false;
		}

	}

}
