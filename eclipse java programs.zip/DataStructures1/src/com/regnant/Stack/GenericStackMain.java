package com.regnant.Stack;

public class GenericStackMain {

	public static void main(String[] args) throws StackOverflowException, StackUnderflowException {

		
		GenericStack <String> obj=new GenericStack<String>();
		obj.push("yellamma");
		obj.push("mallamma");
		obj.pop();
		
		//System.out.println(m);
		obj.show();
		
	}

}
