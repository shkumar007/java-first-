package com.regnant.Stack;

public class Stack {
	int array[] = new int[5];
	int cursor = 0;

	/**
	 * this method is used to push the data into stack .. if stack is full we get
	 * exception of our own exception else normal process
	 * 
	 * @param data
	 * @throws StackOverflowException
	 */
	public void push(int data) throws StackOverflowException {

		if (cursor == 5) {
			throw new StackOverflowException();
		}

		else {
			array[cursor] = data;
			cursor = cursor + 1;
		}
	}

	/**
	 * to delete data at other side of stack if stack is empty we get stack
	 * underflow exception
	 * 
	 * @return
	 * @throws StackUnderflowException
	 */
	public int pop() throws StackUnderflowException {
		int data = 0;
		if (isEmpty()) {
			throw new StackUnderflowException();
		}

		else {
			cursor = cursor - 1;
			data = array[cursor];
			array[cursor] = 0;
		}
		return data;

	}

	
	public boolean isEmpty() {

		return cursor <= 0;
	}

	public void show() {
		for (int i : array) {
			System.out.print(i + " ");
		}
	}

}
