package com.regnant.Stack;

public class GenericStack <E>{
	
		Object array[] = new Object[5];
		int cursor = 0;

		/**
		 * this method is used to push the data into stack .. if stack is full we get
		 * exception of our own exception else normal process
		 * 
		 * @param data
		 * @throws StackOverflowException
		 */
		public <E> void push(E obj) throws StackOverflowException {

			if (cursor == 5) {
				throw new StackOverflowException();
			}

			else {
				array[cursor] = obj;
				cursor = cursor + 1;
			}
		}

		/**
		 * to delete data at other side of stack if stack is empty we get stack
		 * underflow exception
		 * 
		 * @return
		 * @throws StackUnderflowException
		 */
		public <E> E pop() throws StackUnderflowException {
			E data ;
			if (isEmpty()) {
				throw new StackUnderflowException();
			}

			else {
				cursor = cursor - 1;
				data = (E) array[cursor];
				array[cursor] = null;
			}
			return data;

		}

		
		public boolean isEmpty() {

			return cursor <= 0;
		}

		public void show() {
			for (Object i : array) {
				System.out.print(i + " ");
			}
		}

	}


