package com.regnant.Stack;

public class Stackmain {

	public static void main(String[] args) throws StackOverflowException, StackUnderflowException {
		
		Stack obj= new Stack();
		
		obj.push(10);
		obj.push(99);
		obj.push(999);		
		obj.push(100);
		obj.push(996);
		obj.pop();
		obj.pop();
		obj.pop();
		obj.pop();
		obj.pop();
		obj.pop();
		obj.show();
	}

}
