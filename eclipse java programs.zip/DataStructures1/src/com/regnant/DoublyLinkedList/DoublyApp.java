package com.regnant.DoublyLinkedList;

public class DoublyApp {

	public static void main(String[] args) {

		
		DoublylinkedList obj=new DoublylinkedList();
		obj.insert(1);
		obj.insert(2);
		obj.insert(9);
		obj.show();
		
		
	}

}
