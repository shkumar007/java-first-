package com.regnant.DoublyLinkedList;

public class DoublylinkedList {

	NodeDobly head;

	public void insert(int data) {

		NodeDobly obj = new NodeDobly(data);
		obj.next = head;
		obj.previous = null;

		if (head != null) {
			head.previous = obj;
		}

		head = obj;

	}

	public void show() {

		NodeDobly n = head;

		while (head != null) {

			n = head;
			head = head.next;

		}

		System.out.println("Entered elements in Doubly linked list are : ");
		while (n != null) {
			System.out.println(n.data);
			n = n.previous;
		}

	}

}
