package com.regnant.DoublyLinkedList;

public class NodeDobly {

	int data;
	NodeDobly previous;
	NodeDobly next;
	NodeDobly(int data)
	{
		this.data=data;
	}
	
}
