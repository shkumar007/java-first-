package com.regnant.DoubleEndedQueue;

public class DoubleEndedQueue {
  int front=0;
//int size_front=0;
  int array[]=new int[6];
//int rear=5;
  int size_rear=array.length;
  int v=0;
  int pr=0;
public void push_front(int data) {
	for (int i =array.length-1; i >0 ; i--) {
		array[i]=array[i-1];
	}
	array[0]=data;
	front=front+1;
}
public void push_rear(int data) {
	
	/*for (int i =0; i <array.length-1 ; i++) {
		array[i]=array[i+1];
	}
	array[array.length-1]=data;*/
	
array[front]=data;
front=front+1;
pr=pr+1;
}

public int pop_front() {
	
int data=array[v];
for (int i = 0; i < array.length-1; i++) {
	

array[i]=array[i+1];
}
v=v+1;	
	
	return data;
	
}
public int pop_rear() {

	
	
	
	int data=array[pr];
	array[pr-1]=0;
	pr=pr-1;
	
	return data;
}
public void show() {
	for (int i = 0; i < array.length; i++) {
		System.out.print(array[i]+" ");
	}

 }
}
