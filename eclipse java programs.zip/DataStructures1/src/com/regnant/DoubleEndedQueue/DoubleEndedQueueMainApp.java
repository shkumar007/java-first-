package com.regnant.DoubleEndedQueue;

public class DoubleEndedQueueMainApp {

	
	public static void main(String[] args) {

		
		DoubleEndedQueue obj=new DoubleEndedQueue();
		obj.push_front(1);
		obj.push_front(2);
		obj.push_rear(3);
		obj.push_rear(4);
		obj.pop_front();
		obj.pop_front();
		obj.pop_rear();
		obj.pop_rear();
		obj.show();
	
		
		
	}

	

	
}
