package com.regnant.LinkeLlist;

public class LinkedListMainApp {

	public static void main(String[] args) {

LinkedList obj=new LinkedList();

		obj.insert(1);
		obj.insert(2);
		obj.insert(3);
		obj.deleteat(1);
		obj.show();
		
	}
}