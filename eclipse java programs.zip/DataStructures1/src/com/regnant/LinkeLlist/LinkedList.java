package com.regnant.LinkeLlist;

public class LinkedList {
	Node head;

	public void insert(int data) {

		Node node = new Node();
		node.data = data;
		node.objectreference = null;

		if (head == null) {

			head = node;
			
		} else {
			Node n = head;
			while (n.objectreference != null) {
				n = n.objectreference;
			}
			n.objectreference = node;
		}

	}
	public void deleteat(int index) {
		if(index==0) {
		head=head.objectreference;
	}
		else {
			
			
		Node n=head;
		Node n1=null;
		for (int i = 0; i <index-1; i++) {
			n=n.objectreference;
		}
			n1=n.objectreference;
			n.objectreference=n1.objectreference;
			
		}
	}
	

	public void show() {

		Node node = head;

		while (node.objectreference != null) {
			System.out.println(node.data);
			node = node.objectreference;
		}
		System.out.print(node.data);

	}

}













































/*
 * public void insertatstart(int data) { Node node=new Node(); node.data=data;
 * node.next=head; head=node;
 * 
 * }
 */
/*
 * public void insertat(int index,int data) { Node node=new Node();
 * node.data=data; node.next=null; Node n=head; for (int i = 0; i < index-1;
 * i++) { n=n.next; } node.next=n.next; n.next=node; }
 */
