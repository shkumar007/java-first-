package com.regnant.LinkeLlist;
public class Node {
	
	
	int data;
	Node objectreference;
	
	
	
}