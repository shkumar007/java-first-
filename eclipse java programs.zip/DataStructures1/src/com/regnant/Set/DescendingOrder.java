package com.regnant.Set;

public class DescendingOrder {
	/***
	 * Here, i am arranging array element into Descending order
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		int array[] = { 1, 9, 8, 5, 6, 7, 4 };
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length - 1 - i; j++) {
				int temp = 0;
				if (array[j] < array[j + 1]) {
					temp = array[j];
					array[j] = array[j + 1];
					array[j + 1] = temp;

				}

			}
		}
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}

	}

}
