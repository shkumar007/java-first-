package com.regnant.Set;

public class ArrayAscendingOrder {
	/***
	 * Here, i am arranging array element into Ascending order
	 * 
	 * @param args
	 */

	public static void main(String[] args) {

		int array[] = { 1, 10, 3, 499, 50, 1999 };

		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array.length - 1 - i; j++) {
				int temp = 0;
				if (array[j] > array[j + 1]) {
					temp = array[j];
					array[j] = array[j + 1];
					array[j + 1] = temp;
				}
			}

		}

		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}

	}

}
