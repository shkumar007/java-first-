package com.regnant.Set;

import java.util.Scanner;

public class Set {

	public static void main(String[] args) {

		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the array size : ");
		int size=sc.nextInt();
		
		int array[]=new int[size];
		
		int element;
		loop:
		for (int i = 0; i < array.length; i++) {
			element=sc.nextInt();
			
			for (int j = 0; j < i; j++) {
				if(element==array[j]) {
					
					System.out.println("entered element is already present in array");
					i--;
					continue loop;
				}
			}
			array[i]=element;
			
			
			
		}
		
		
		for (int i = 0; i < array.length; i++) {
			System.out.println(array[i]+" ");
		}
		
		
	}

}
