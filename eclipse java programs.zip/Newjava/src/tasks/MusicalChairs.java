package tasks;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class MusicalChairs {

	public static void main(String[] args) throws InterruptedException {
		Lock l = new ReentrantLock();

		l.lock();
		Queue<Integer> li = new LinkedList<>();
		li.add(1);
		li.add(2);
		li.add(3);
		li.add(4);
		li.add(5);
		l.unlock();

		Thread t1 = new Thread(new Runnable() {

			@Override
			public void run() {

				System.out.println(li.remove() + "::::::::::" + Thread.currentThread().getName());
			}
		});

		Thread t2 = new Thread(new Runnable() {

			@Override
			public void run() {

				System.out.println(li.remove() + " ::::::::::::::::: " + Thread.currentThread().getName());
			}
		});

		Thread t3 = new Thread(new Runnable() {

			@Override
			public void run() {

				System.out.println(li.remove() + " :::::::::::::::" + Thread.currentThread().getName());
			}
		});

		Thread t4 = new Thread(new Runnable() {

			@Override
			public void run() {

				System.out.println(li.remove() + " :::::::::::::::" + Thread.currentThread().getName());
			}
		});
		Thread t5 = new Thread(new Runnable() {

			@Override
			public void run() {

				System.out.println(li.remove() + " :::::::::::::::" + Thread.currentThread().getName());
			}
		});
		Thread t6 = new Thread(new Runnable() {

			@Override
			public void run() {

				System.out.println(li.remove() + " :::::::::::::::" + Thread.currentThread().getName());
			}
		});

		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
		t6.start();

	}

}
