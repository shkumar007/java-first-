package tasks;

import java.util.Date;

public class GenarateRaandomNumber {

	public static void main(String[] args) {
		int b = (int) (ttime() % 100);
		System.out.println(b);

	}

	public static long ttime() {
		Date t = new Date();
		return t.getTime();

	}

}
