package tasks;

import java.util.Random;

public class Regestration_Numbers_for_Bikes {
public static void main(String[] args) {
	String[] st = { "Ap", "AR", "AS", "BR", "CG", "GJ", "GA", "HR", "HP", "JK", "JH", "JK", "KL", "MP", "MH", "MN",
			"ML", "MZ", "NL", "OR", "PB", "RJ", "SK", "TN", "TR", "UK", "UP", "WB", "TS", "TR", "AN", "CH", "DH",
			"DD", "DL", "LD", "PY" };
	
	
	Random ran = new Random();

	String Str = st[ran.nextInt(st.length)];
	
	int number1=(int)(Math.random()*100);

	char ch1=(char)(65+(Math.random()*(90-65)));
	char ch2=(char)(65+(Math.random()*(90-65)));
	 
	int number2=(int)(Math.random()*(9999-1000));
	
	
	System.out.println("regestration numbers are:");
	System.out.println(Str+" "+number1+" "+ch1+ch2+" " +number2);
	}
}
