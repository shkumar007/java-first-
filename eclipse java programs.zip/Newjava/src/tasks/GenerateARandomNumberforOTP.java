package tasks;


public class GenerateARandomNumberforOTP {

	public static void main(String[] args) {

		
		int  x=(int) getRandomDoubleBetweenRange(1000,9999);
		System.out.println("hi otp : "+x+" for transaction");
		
	}
	public static double getRandomDoubleBetweenRange(double min, double max){
	    double x = (Math.random()*((max-min)+1))+min;
	    return x;
	}
}
