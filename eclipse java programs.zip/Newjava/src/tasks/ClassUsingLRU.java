package tasks;

public class ClassUsingLRU {

	int ar[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
	int temp = 0;

	public static void main(String[] args) {
		ClassUsingLRU obj = new ClassUsingLRU();
		int result[] = obj.next();
		// int result2[] = obj.get();
		// int result3[] = obj.get();

		display(result);
		// display(result2);
		// display(result3);
	}

	public static void display(int[] result) {
		for (int i = 0; i < result.length; i++) {
			System.out.print(result[i] + "   ");
		}
	}

	public int[] next() {

		int x = ar[temp];
		temp++;
		int y = ar[temp];
		temp++;

		int z[] = { x, y };

		return z;

	}

}
