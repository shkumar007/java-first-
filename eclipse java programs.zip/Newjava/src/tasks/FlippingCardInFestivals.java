package tasks;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class FlippingCardInFestivals {

	public static void main(String[] args) {

		String[] heros = { "power *", "young puli", "super *", "mega power star" };

		Random r = new Random();
		String m = heros[r.nextInt(heros.length)];

		System.out.println(m);

		HashMap<Integer, String> Hero1 = new HashMap<>();
		Hero1.put(100, "player1");
		Hero1.put(200, "player2");
		Hero1.put(50, "player3");

		HashMap<Integer, String> Hero2 = new HashMap<>();
		Hero2.put(100, "player4");
		Hero2.put(200, "player2");
		Hero2.put(50, "player5");

		if (m.equals("power *")) {

			display(Hero1);
		} else if (m.equals("young puli")) {
			display(Hero2);
		} else {
			int sum = 0;
			sum = ownerprofit(Hero1, sum);
			sum = ownerprofit(Hero2, sum);

			System.out.println("owner got the total amount");
			System.out.println(sum);
		}

	}

	public static int ownerprofit(HashMap<Integer, String> Hero1, int sum) {
		for (Map.Entry l : Hero1.entrySet()) {
			sum = sum + ((int) l.getKey());
		}
		return sum;
	}

	@SuppressWarnings("rawtypes")
	public static void display(HashMap<Integer, String> lll) {
		for (Map.Entry l : lll.entrySet()) {
			System.out.println(((int) l.getKey()) * 2 + ":::: " + l.getValue());
			System.out.println("had doubled the amont");
		}
	}

}
