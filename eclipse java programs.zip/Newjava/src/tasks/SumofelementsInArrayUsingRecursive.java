package tasks;

public class SumofelementsInArrayUsingRecursive {

	public static void main(String[] args) {

		int[] array = arr();

		System.out.println(get(array, array.length, 0));

	}

	public static int[] arr() {
		int array[] = new int[100];
		for (int i = 1; i < array.length; i++) {
			array[i] = i;
		}
		return array;
	}

	private static int get(int A[], int i, int j) {

		if (j < i)

		{

			return A[j] + get(A, i, ++j);
		}

		else {
			return 0;
		}

	}

}
