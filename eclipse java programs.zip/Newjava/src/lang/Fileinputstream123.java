package lang;

import java.io.FileReader;
import java.io.IOException;

public class Fileinputstream123 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		FileReader fin = new FileReader("F:\\package2\\ONE.txt");
		int i;
		while ((i = fin.read()) != -1)
			System.out.print((char) i);

	}

}
