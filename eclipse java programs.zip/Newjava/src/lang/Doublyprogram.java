package lang;

public class Doublyprogram {

	Doubly head;
	public void add(int data)
	{
		Doubly obj=new Doubly(data);
		
		obj.next=head;
		obj.previous=null;
		if(head!=null) {
			head.previous=obj;
		}
		head.next=obj;
	}
	
	public void show() {
		Doubly n=head;
		while(head!=null) {
		n=head;
		head=head.next;
		}
		while(n!=null) {
			System.out.println(n.data);
			n=n.previous;
		}
		
	}
}
