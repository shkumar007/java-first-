package lang;

public class Hass {

	 

	public static void main(String[] args) {
		
		System.out.println("mava");
		
	}

}
