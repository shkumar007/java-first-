package lang;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.hssf.usermodel.*;

public class Xcellread {

	public static void main(String[] args) throws FileNotFoundException {

		try {
			File excel = new File("F:\\package2\\ONE.xls");
			FileInputStream fis = new FileInputStream(excel);
			HSSFWorkbook book = new HSSFWorkbook(fis);

			for (int i = 0; i < book.getNumberOfSheets(); i++) {
				HSSFSheet sheet = book.getSheetAt(i);

				// Do your stuff

				Iterator<Row> itr = sheet.iterator();
				// Iterating over Excel file in Java
				while (itr.hasNext()) {
					Row row = itr.next();

					// Iterating over each column of Excel file
					Iterator<Cell> cellIterator = row.cellIterator();
					while (cellIterator.hasNext()) {

						Cell cell = cellIterator.next();

						switch (cell.getCellType()) {
						case Cell.CELL_TYPE_STRING:
							System.out.print(cell.getStringCellValue() + "\t");
							break;
						case Cell.CELL_TYPE_NUMERIC:
							System.out.print(cell.getNumericCellValue() + "\t");
							break;
						case Cell.CELL_TYPE_BOOLEAN:
							System.out.print(cell.getBooleanCellValue() + "\t");
							break;
						default:

						}
					}
					System.out.println("");
				}
			}
		} catch (IOException e) {
		}
	}
}
