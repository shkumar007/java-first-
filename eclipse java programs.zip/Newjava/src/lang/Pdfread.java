package lang;



	import com.itextpdf.text.pdf.PdfReader;
	import com.itextpdf.text.pdf.parser.PdfTextExtractor;

	public class Pdfread {
	  public static void main(String args[]){
	    try {
		
		PdfReader pdfReader = new PdfReader("C:\\Users\\new\\Desktop\\sql syntax.pdf");	
		int pages = pdfReader.getNumberOfPages(); 
	 
		for(int i=1; i<=pages; i++) { 
		  
		  String pageContent = 	PdfTextExtractor.getTextFromPage(pdfReader, i);
	 
		  System.out.println("------------------");
		  System.out.println("Content on Page" + i + ": " + pageContent);
		  System.out.println("------------------");
	      }
	 
	    
	      pdfReader.close();
	    } catch (Exception e) {
		e.printStackTrace();
	    }
	  }
	}

