package lang;

public class alternativeprimes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]=new int[20];
		int c=0;
		for (int i = 1; i <50; i++) {
			
		int temp=0;
		for (int j = i; j >= 1; j--)
		{
			if(i%j==0) 
			{
				temp=temp+1;
			}
			}
		if(temp==2) {
		a[c]=i;
		c++;
		
		}
		
		
	}
		for (int i = 0; i < c; i=i+2) {
			System.out.println(a[i]);
			
		}
	}

}
