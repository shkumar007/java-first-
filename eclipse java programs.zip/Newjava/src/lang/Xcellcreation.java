package lang;
import  java.io.*;
import  org.apache.poi.hssf.usermodel.HSSFSheet;
import  org.apache.poi.hssf.usermodel.HSSFWorkbook;
import  org.apache.poi.hssf.usermodel.HSSFRow;

public class Xcellcreation{
    public static void main(String[]args) {
        try {
            
            HSSFWorkbook m = new HSSFWorkbook();
            HSSFSheet sheet = m.createSheet("FirstSheet");  

            HSSFRow rowhead = sheet.createRow(0);
            rowhead.createCell(0).setCellValue("No.");
            rowhead.createCell(1).setCellValue("Name");
            rowhead.createCell(2).setCellValue("Address");
            rowhead.createCell(3).setCellValue("Email");
           
          
            HSSFWorkbook n = new HSSFWorkbook();
            HSSFSheet sheet2 = n.createSheet("Second");  
            
            HSSFRow row = sheet2.createRow(0);
            row.createCell(0).setCellValue("1");
            row.createCell(1).setCellValue("Hemanth");
            row.createCell(2).setCellValue("Bangalore");
            row.createCell(3).setCellValue("mama ek beg laa");
            

            FileOutputStream fileOut = new FileOutputStream("F:\\package2\\two.xls");
            m.write(fileOut);
           
           
            fileOut.close();
          
            System.out.println("excel file has been generated!");

        } catch ( Exception ex ) {
            System.out.println(ex);
        }
    }
}