package lang;

public class Doubly {
int data;
Doubly previous;
Doubly next;

public Doubly(int data) {
	this .data=data;
}
}
