package lang;

public class coprima {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (int i = 0; i < 50; i++) {
			if (prime(i) == true && prime(i + 2) == true) {
				System.out.println(i + ", " + (i + 2));
			}
		}

	}

	static boolean prime(int i) {
		int temp = 0;
		for (int j = i; j > 0; j--) {
			if (i % j == 0) {
				temp = temp + 1;
			}
		}
		if (temp == 2) {
			return true;
		} else {
			return false;
		}

	}
}
