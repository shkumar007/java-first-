package lang;

import java.io.BufferedOutputStream;
//import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import java.io.IOException;
import java.util.Scanner;

public class Fileouputstream123 {

	public static void main(String[] args) throws IOException {

		Scanner sc = new Scanner(System.in);
		System.out.println("enter the data : ");
//		int b=sc.nextInt();
		String inputstring = sc.nextLine();
		/*
		 * System.out.println("enter integer values "); int x=sc.nextInt();
		 */

		// FileOutputStream fout=new FileOutputStream("F:\\package2\\Three.txt");
		BufferedOutputStream ooo = new BufferedOutputStream(new FileOutputStream("F:\\package2\\Three.txt"));
		ooo.write(inputstring.getBytes());

//		 fout.write(b);

		sc.close();
		ooo.close();
		System.out.println("Success :) :) :) :)");
	}

}
