package Atm;
import java.util.Scanner;

public class Arraytask2 {
	

		static int[] ary;
		
		
		public static void main(String[] args) {
			Scanner sc = new Scanner(System.in);
			ary = new int[5];
			System.out.println("Enter 5 elements in Base array  ");
			for(int i = 0; i<5;i++) {
				ary[i] = sc.nextInt();
			}
			System.out.println("Your Base array size is "+ary.length);
			System.out.println("Base array address BEFORE modifying "+ ary);
			System.out.println(" Enter your option: \n 1. Add an element\n 2. Add multiple elements\n 3. Delete an element");
			int ch = sc.nextInt();
			switch(ch) {
			case 1 :
				addElement(ary); //adding only one element
				break;
			case 2:
				System.out.println("No of elements do you want to add ");
				int add_size = sc.nextInt();
				int[] add = new int[add_size];
				System.out.println("Enter "+add_size+" elements");
				for(int i = 0; i<add_size; i++)
				add[i] = sc.nextInt(); 
				addElements(ary,add); //adding multiple elements
				break;
			case 3:
				System.out.println("Array Index : 0 to "+(ary.length-1)+"\nEnter position no you want to delete ");
				int position = sc.nextInt();
				delElement(ary,position); //deleting one position 
				break;
			default:
				System.out.println("choose either 1 or 2 or 3");
				break;
				}
		}
		
		static void addElement(int array1[])
		{
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter any number to append ");
			int num = sc.nextInt();
			int new_size = array1.length+1,t=0;	
			int[] array2 = new int[new_size];
			ary = new int[new_size];
			for(int i=0; i<new_size; i++)
			{
				if(i<array1.length) {
				array2[i] = array1[i];
				}
				else
				array2[i] = num;	
			}
			System.out.println("Base array address AFTER modifying "+ ary);
			System.out.println("Modified Array size "+ary.length);		
			for(int y : array2)
				ary[t++] = y;
			for(int i=0; i<Arraytask2.ary.length;i++)
			System.out.println(Arraytask2.ary[i]);
			}
		
		static void addElements(int array1[], int array2[])
		{
			
			int new_size = array1.length + array2.length;
			ary = new int[new_size];
			//int[] array3 = new int[new_size];
			for(int i=0; i<new_size; i++)
			{
				if(i<array1.length) {
				ary[i] = array1[i];
				}
				else
				ary[i] = array2[i-array1.length];	
			}
			System.out.println("Base array address AFTER modifying "+ ary);
			System.out.println("Modified Array size "+ary.length);	
			for(int y : ary) {
			System.out.println(y);
			}
		}	
		static void delElement(int array[],int position) {
			int new_size = array.length - 1, j=0,t=0;
			ary = new int[new_size];
			System.out.println("Base array elements ");	
			for(int z : array)
				System.out.println("Positio "+(t++)+" --> "+z);
			//int[] array2 = new int[new_size]; 
			array[position]=0;
				for(int x : array) {
					if(x == 0)
						continue;
					ary[j++]=x;				
				}		
				System.out.println("Base array address AFTER modifying "+ ary);
				System.out.println("Modified Array size "+ary.length);	
			for(int z : ary)
				System.out.println(z);
		}
		

	}


