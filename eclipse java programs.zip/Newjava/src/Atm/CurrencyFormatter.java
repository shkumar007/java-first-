package Atm;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.Scanner;

public class CurrencyFormatter {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.println("pls enter amount : ");
        double payment = scanner.nextDouble();
		Locale indialocale=new Locale("en","IN");
		NumberFormat India=NumberFormat.getCurrencyInstance(indialocale);
		NumberFormat us=NumberFormat.getCurrencyInstance(Locale.US);
		System.out.println(India.format(payment));
		System.out.println(us.format(payment));
		
		
		
		
	}

}
