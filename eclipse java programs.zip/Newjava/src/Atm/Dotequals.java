package Atm;

public class Dotequals {

	public static void main(String[] args) {

		Thread t= new Thread();
		 System.out.println(t.equals(null));
		
		
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		return super.equals(obj);
	}

}
