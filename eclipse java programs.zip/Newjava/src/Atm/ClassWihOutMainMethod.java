package Atm;

public class ClassWihOutMainMethod {
	public static void main(String[] args) {

		Thread t1 = new Thread(new Aone());
		t1.start();
	}
}

class Aone implements Runnable {

	String str[] = { " red ", " green ", " yellow " };

	@Override
	public void run() {
		while (true) {
			for (int i = 0; i < str.length; i++) {
				System.out.println(str[i]);
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

}