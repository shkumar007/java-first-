package Atm;

import java.util.Scanner;

public class Arraytask {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		int array[] = new int[3];

		System.out.println("pls select option \n1.push \n2.remove");
		int optionselect = sc.nextInt();
		switch (optionselect) {
		case 1:
			array = Push(array);
			break;

		case 2:
			array = remove(array);
			break;
		case 3:
			System.exit(0);
		}

		for (int i = 0; i < array.length - 1; i++) {
			System.out.print(array[i]);
		}
	}

	private static int[] remove(int[] array) {

		System.out.println("enter the elements into array :");
		for (int i = 0; i < array.length; i++) {
			array[i] = sc.nextInt();
		}
		System.out.println("enter the removable element");
		int removableelement = sc.nextInt();

		for (int i = 0; i < array.length; i++) {
			if (array[i] == removableelement) {
				for (int j = i; j < array.length - 1; j++) {
					array[j] = array[j + 1];
				}
				break;
			}
		}

		return array;
	}

	public static int[] Push(int[] array) {

		System.out.println("enter the elements");
		for (int i = 0; i < 5; i++) {

			if (i == array.length) {

				int temp[] = new int[array.length];
				temp = array;
				int test[] = testing(array.length);
				array = test;
				for (int j = 0; j < temp.length; j++) {
					array[j] = temp[j];
				}

			}
			array[i] = sc.nextInt();

		}
		return array;
	}

	private static int[] testing(int length) {
		int a[] = new int[length + 10];

		return a;
	}

}
