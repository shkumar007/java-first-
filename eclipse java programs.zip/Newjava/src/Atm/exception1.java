package Atm;



public class exception1 extends Exception {

	public exception1() {
		System.out.println("mama");
	}
	
	

}
