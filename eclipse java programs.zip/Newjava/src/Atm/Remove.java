package Atm;

public class Remove {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a = new int[] {10,2,3,4,5,4,6,7,8,9};
		int rv1= 1,rv2=4;
		for (int i = 0; i < a.length-1; i++) {
			if(i>=rv1  )
			{
				a[i]=a[i+1];
			}
		}
		for (int i = 0; i < a.length-1; i++) {
			System.out.print(a[i]+" ");
		}
	}

}
