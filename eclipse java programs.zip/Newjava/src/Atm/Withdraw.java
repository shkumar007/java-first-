package Atm;

import java.util.Scanner;
public class Withdraw{
	
//public int updated_balance=0;
	int balance=1000000;
public void a(){

	 //
Scanner sc= new Scanner(System.in);
System.out.println("pls enter the amount required");
int y=sc.nextInt();
//public void a(int y){
if(balance>0 && y<=balance){
//System.out.println("your entered amount is processing... ");
System.out.println("first bank lo dabbulu veyi ra");
}
}
public void up_bal(int y) { 
	 int updated_balance=0;
	updated_balance=balance-y;
	System.out.println("balance remaining is: "+ updated_balance);

}
}

