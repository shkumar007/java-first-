package Atm;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class CopyfileFromOneFolderToAnother {

	public static void main(String[] args) throws IOException {

		File from = new File("F:\\package2\\One.txt");
		File to = new File("F:\\package2\\Three.txt");

		// copyFile("F:\\package2\\One.txt","F:\\package2\\Three.txt");

	}
	
	public static void copy(File src, File dest) throws IOException {
		FileInputStream is = null;
		FileOutputStream os = null;

		try {
			is = new FileInputStream(src);
			os = new FileOutputStream(dest);

			 byte[] buf = new byte[1024];

			int bytesRead;
			while ((bytesRead = is.read(buf)) > 0) {
				os.write(buf, 0, bytesRead);
				
				
			}
		} finally {
			is.close();
			os.close();
		}
	}

	public static void copyFile(String from, String to) throws IOException {
		Path m = Paths.get(from);
		Path n=Paths.get(to);
		Files.copy(m,n);
	}

}
