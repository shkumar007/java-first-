package Atm;


public class AAAA {


	
	public static void main(String[] args) {
		
	int v=0;

		
	System.out.println(v);
	
	v=10;
	
	System.out.println(v);
	
	}
		
}
