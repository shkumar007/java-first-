package Atm;

public class Exceptions {

	public static void main(String[] args) {
	
		doo();
		System.out.println("");
		System.out.println(8/0);
	}
	public static void doo() {
		
		domore();
		System.out.println("hi");
	}
	private static void domore() {
		
		System.out.println("hi iam in domore");
		
	}
	

}
