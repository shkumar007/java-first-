package util;

import java.util.Scanner;

public class Findsum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		int a[] = { 0, 1, 2, 3, 4, 5, 6 };
		System.out.println("Enter value :");
		int sum = sc.nextInt();

		for (int i = 0; i < a.length; i++) {

			int m = a[i];
			for (int j = 0; j < a.length; j++) {

				int n = a[j];
				if ((m + n) == sum)
					System.out.println("(" + m + "," + n + ")");
			}
		}

	}

}
