package util;

public class Removingcharacfromstring {

	public static void main(String[] args) {
		//using delete charat method
		/*String s="hemanth";
	    StringBuilder sb = new StringBuilder(s);
		String name=sb.deleteCharAt(3).toString();
          System.out.println(name);*/

	
		String s="hemanth";
		String name1="";
		for (int i = 0; i < s.length(); i++) {
			if(s.charAt(i)!='t') 
		
		 	name1=name1+s.charAt(i);
			
		}
		System.out.println(name1);
	}

}
