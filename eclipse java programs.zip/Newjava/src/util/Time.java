package util;

import java.util.Scanner;

public class Time {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("Pls enter hours required :");
        int hours=sc.nextInt();
        System.out.println("Pls enter minutes required :");
        int minutes=sc.nextInt();
        System.out.println("Pls enter seconds required :");
        int seconds=sc.nextInt();
        System.out.println("Pls enter am/pm :");
        String s=sc.next();
       if(hours<12 &&s.equalsIgnoreCase("pm"))
		{
			hours=hours;
			
		}
		else if(hours>=12 && hours<=24 && s.equalsIgnoreCase("am") )
		{
			hours=hours-12;
			
		}
		
		if(minutes<60)
		{minutes=minutes;}
		else if(minutes==60)
			{hours=hours+1;
			minutes=0;}
		
		if(seconds<60)
		{seconds=seconds;}
		else if(seconds==60)
			{minutes=minutes+1;
			seconds=0;}
		
		
		if(s.equalsIgnoreCase("am"))
		System.out.println(hours+":"+minutes+":"+seconds+ s);
		else
			System.out.println(hours+":"+minutes+":"+seconds);
		
		/*Scanner sc=new Scanner(System.in);
		System.out.println("Pls enter hours required :");
        int hours=sc.nextInt();
        System.out.println("Pls enter minutes required :");
        int minutes=sc.nextInt();
        System.out.println("Pls enter seconds required :");
        int seconds=sc.nextInt();
        System.out.println("Pls enter am/pm :");
        String s=sc.next();
       if(hours<12 &&s.equalsIgnoreCase("am")&&minutes<60&&seconds<60)
		{
			hours=hours;
			
			System.out.println(hours+":"+minutes+":"+seconds+ s);
		}
		
		else if (hours>=12 && hours<=24 && s.equalsIgnoreCase("pm")&& minutes==60 && seconds==60)
		{
			hours=hours-12;
			hours=hours+1;
			minutes=0;
			minutes=minutes+1;
			seconds=0;
			
			System.out.println(hours+":"+minutes+":"+seconds);
		}
		
     if(s.equalsIgnoreCase("am"))
   		System.out.println(hours+":"+minutes+":"+seconds+ s);
   		else
   			System.out.println(hours+":"+minutes+":"+seconds);*/
		
	

}

	}


