package util;

import java.util.*;
import java.io.*;

class HackersRank{
    public static void main(String []args){
        Scanner in = new Scanner(System.in);
        System.out.println("ENTER T VALUE:");
        int t=in.nextInt();
       for(int i=1;i<=t;i++)
       {
        	System.out.println("ENTER A VALUE:");
            int a = in.nextInt();
            System.out.println("ENTER B VALUE:");
            int b = in.nextInt();
            System.out.println("ENTER N VALUE:");
            int n = in.nextInt();
        int res=a;
       for (int j = 0; j < n; j++)
            {
                res += (int)(Math.pow(2, j) * b);
                System.out.print(Integer.toString(res)  + ' ');
            }
       
            System.out.println();
       
       }
      
    }
}

