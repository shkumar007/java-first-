package util;
import java.util.Scanner;

public class Details {

	public static void main(String[] args) {
		/*Scanner sc= new Scanner(System.in);
		System.out.println("Eneter number : ");
		int a =sc.nextInt();
		System.out.println("Eneter other number : ");
		int b= sc.nextInt();
		System.out.println("Please select from below options");
		System.out.println("1.add");
		System.out.println("2.sub");
		System.out.println("3.mul");
		System.out.println("4.Div");
		System.out.println("5.mod");
		int c= sc.nextInt();
switch(c){
case 1:System.out.println("addition is :" +(a+b));
break;
case 2:System.out.println("Subtraction is :" +(a-b));
break;
case 3:System.out.println("multiplication is :" +(a*b));
break;
case 4:System.out.println("Division is :" +(a/b));		
break;
case 5:System.out.println("module is :" +(a%b));
break;		
default:	System.out.println("Pls enter the correct option" );
	} 

		Scanner sc= new Scanner(System.in);
		System.out.println("Enter month:");
		int x=sc.nextInt();
		
		String s="";
		switch(x)
		{
		case 1:s="1-january";
		break;
		case 2:s="2-February";
		break;
		case 3:s="3-March";
		break;
		case 4:s="4-april";
		break;
		case 5:s="5-may";
		break;
		case 6:s="6-june";
		break;
		case 7:s="7-july";
		break;
		case 8:s="8-August";
		break;
		case 9:s="9-September";
		break;
		case 10:s="10-october";
		break;
		case 11:s="11-november";
		break;
		case 12:s="12-december";
		break;
		default:s="Invalid month";
		break;
	}
		
		System.out.println(s);*/
		
		/*Scanner sc= new Scanner(System.in);
		System.out.println("Enter the value : ");
		int x=sc.nextInt();
		int z=0,a=0;
		while(x>0)
		{	z=x%10;
		a=a+z;
		x=x/10;
		}
		else 
			System.out.println("wrong input");
		
		System.out.println(a);*/		
		//System.out.print(z);

	/*
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the value : ");
		int x=sc.nextInt();
		//String s=((x%2==0 && x>=2 && x<=5) || (x>20) ) ? "nk":"k";
		System.out.println(((x%2==0 && x>=2 && x<=5) || (x>20) ) ? "nk":"k");
		}*/
	
	
	
	
	
	
	}}