package util;

public class Palindrome {

	public static void main(String[] args)  throws java.lang.Exception 
	{
		// TODO Auto-generated method stub
String s="oxo oxo";
char []ch=new char[s.length()];

for (int i = 0,j=s.length()-1; j >=0 ;j--, i++) {
	ch[i]=s.charAt(j);
	
}
String s1=new String(ch);
if(s.equals(s1))
	System.out.println("pal");
else
	System.out.println("not pal");

	}
	

}
