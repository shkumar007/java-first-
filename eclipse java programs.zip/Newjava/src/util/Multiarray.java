package util;

import java.util.Scanner;

public class Multiarray {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		/*System.out.println("enter rows and coloumns : ");
		int r=sc.nextInt();
		int c=sc.nextInt();
		int arr[] []= new int [r][c];
		System.out.println("Enter elements : ");
		for (int i = 0; i <r; i++) 
		{
		for (int j = 0; j <c; j++)
		{ 
		 arr[i][j]=sc.nextInt();
		
		}
		}
		for (int i = 0; i <r; i++) 
		{
		for (int j = 0; j <c; j++)
		{ 
		   System.out.print(arr[i][j] + " ");
		}
		System.out.println("\n");
		}
		//System.out.println();
		*/
	int arr[][][]= {{{10,20,30,50},{50,90,80,70}},
			{{1,8,97,66},{1,5,8,99}},
			{{22,99,100,77},{55,99,77,75}}};
	int dept,marks,student,total=0;
	for ( dept= 0; dept <3; dept++)
	{
		
		
		System.out.println("Department"+(dept+1)+":");
		for (student=0; student <2;student++)
		{
			
			System.out.print("Student"+(student+1)+":");
		
			for(marks=0;marks<4;marks++)
			{
				
				System.out.print(arr[dept][student][marks]+" ");
				total=total+arr[dept][student][marks];
			}
			System.out.println("total marks :"+total);
			total=0;
		}
		System.out.println();
	}	
}
}
