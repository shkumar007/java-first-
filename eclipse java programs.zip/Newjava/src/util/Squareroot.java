package util;

import java.util.Scanner;

public class Squareroot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		double x = sc.nextDouble();
		double y = Math.sqrt(x);
		System.out.println(y);

	}

}
