package util;

import java.util.Scanner;

public class Stringsplit {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter string:");
		String s=sc.nextLine();
		String m[]= s.split(" ");
		//String g="";
		for (int i = 0; i < m.length; i++) {
			if(i%2==0) 
			{
				m[i]=m[i].toUpperCase();
		}else {
			StringBuffer sb=new StringBuffer(m[i]);
			m[i]=sb.reverse().toString();
		}
			
			
				
		}
			for (String string : m) {
				System.out.print(string+" ");
			}
	}
			
			
	}
	


