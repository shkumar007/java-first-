package util;
import lang.Hass;
public class Package {

	public static void main(String[] args) {
		String arr[]= {"fgg"};
		Hass.main(arr);
		
System.out.println("i amm in package");
	}

}
