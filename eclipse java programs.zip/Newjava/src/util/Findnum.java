package util;

import java.util.Scanner;

public class Findnum {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter name to find :");
		String test = sc.next();

		int m = 0;
		String a[] = { "India", "us", "rsa", "aus", "china", "pak" };
		for (int i = 0; i < a.length; i++) {

			if (a[i].equalsIgnoreCase(test)) {
				m = m + 1;
				System.out.println("value is present at a[" + i + "] position");
			}
		}
		if (m == 0)
			System.out.println("value   " + test + " not present in array");

	}

}
