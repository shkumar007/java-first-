package util;

public class Reversenames {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*//reversing an array
		Scanner sc= new Scanner(System.in);
		String string = " very good  hemanth kumar  ".trim();
		String array[] = string.split(" ");

		for (int j = array.length - 1; j >= 0; j--) {
			System.out.print(array[j] + " ");
		}*/
String s1="";
		String s="hemanth";
		char ch[]=s.toCharArray();
		char temp;
		for (int i = 0; i < ch.length; i++) {
			for (int j = 0; j < ch.length; j++) {
				
if(ch[i]<ch[j])
	{
	temp=ch[i];
	
ch[i]=ch[j];
ch[j]=temp;
				
	}}}
for (int i = 0; i < ch.length; i++) {
	s1=s1+ch[i];
}
				System.out.println(s1);
				
			}
		}
		
		
