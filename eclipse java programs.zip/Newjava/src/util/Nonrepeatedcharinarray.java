package util;

public class Nonrepeatedcharinarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="hemanth";
		char c[]=new char[s.length()];
		for (int i = 0; i < s.length(); i++) {
			c[i]=s.charAt(i);
			
		}
		for(char c1:c) {
		System.out.println(c1);
		}
		for (int i = 0; i < c.length; i++) {
			
		}
		
		
		
	}

}
