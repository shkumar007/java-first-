package util;

import java.util.Scanner;

public class Methodarray {

	public static void main(String[] args) {
		/*
		 * // finding smallest number in an array int a[]= {10,2,3};
		 * 
		 * m(a);
		 * 
		 * 
		 * } static void m(int a[]) { int h=a[0]; for (int j = 0; j < a.length; j++) {
		 * 
		 * 
		 * if(h<a[j])// if(h>a[j]) { h=a[j]; }
		 * 
		 * } System.out.println(h);
		 */
		/*
		 * //petrol pumping program Scanner sc=new Scanner(System.in);
		 * System.out.println("Enter amount : "); double money=sc.nextDouble(); double
		 * rate=96.5; double onerupee=1000/rate; double tot=money*onerupee;
		 * 
		 * if(tot>1000) { tot=tot/1000;
		 * 
		 * 
		 * System.out.printf("%.3f",tot); System.out.print (" lit");
		 * 
		 * } else System.out.println("petrol out is :"+tot+ "ml");
		 */

		/*
		 * Scanner sc=new Scanner(System.in);
		 * System.out.println("Pls enter time required :"); double time=sc.nextDouble();
		 * double y=0; if(time<=12) {System.out.println("time is : "+time+" am"); } else
		 * if(time>12 && time<=24) {y=time-12; System.out.println("time is : "+y+" pm");
		 * } else { System.out.println("time cannot be greater than 24 hours"); }
		 */

		/*
		 * Scanner sc=new Scanner(System.in);
		 * 
		 * System.out.println("pl enter string :"); String s=sc.nextLine(); char ch='h';
		 * int m=0; for (int i = 0; i < s.length(); i++) {
		 * 
		 * if(s.charAt(i)==ch) { m=m+1;}
		 * 
		 * 
		 * }
		 * 
		 * 
		 * System.out.println(ch+"   is present in string "+m+" times");
		 * 
		 * 
		 * 
		 * 
		 * 
		 * }
		 * 
		 */

		Scanner sc = new Scanner(System.in);
		System.out.println("enter day :");
		int d = sc.nextInt();
		System.out.println("enter month :");
		int m = sc.nextInt();

		System.out.println("enter year: ");
		int g = sc.nextInt();

		if (m > 2) {
			m = m - 2;
		} else if (m <= 3) {
			m = m + 10;

			g = g - 1;
		}
		int c = g / 100;
		int D = g % 100;
		int day = (d) + ((13 * m - 1) / 5) + (D) + (D / 4) + (c / 4) - (2 * c);
		int v = ((day) % 7);

		switch (v) {
		case 1:
			System.out.println("the day is monday");
			break;
		case 2:
			System.out.println("the day is tuesday");
			break;
		case 3:
			System.out.println("the day is wednesday");
			break;
		case 4:
			System.out.println("the day is thursday");
			break;
		case 5:
			System.out.println("the day is friday");
			break;
		case 6:
			System.out.println("the day is saturday");
			break;
		case 0:
			System.out.println("the day is sunday");
			break;
		}

	}
}
