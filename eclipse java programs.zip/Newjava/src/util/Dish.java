package util;

import java.util.Scanner;

public class Dish {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s1 = "Airtel";
		String s2 = "Apfibernet";
		String s3 = "Hathway";
		Scanner sc = new Scanner(System.in);
		System.out.print("Required connection : ");

		String name = sc.nextLine();
		// System.out.println(name);
		// System.out.println("Selected connection : " +name);
		if (name.equalsIgnoreCase(s1)) {
			int budget = 100;
			int semi = (budget * 6) - budget;
			int annual = (budget * 12) - (2 * budget);
			System.out.println("Airtel charges are");
			System.out.println("monthly charges are:" + budget);
			System.out.println("Semi year charges are : " + semi);
			System.out.println("Annual year charges are : " + annual);
		} else if (name.equals(s2)) {
			int budget = 120;
			int semi = (budget * 6) - budget;
			int annual = (budget * 12) - (2 * budget);
			System.out.println("AP fibernet charges are");
			System.out.println("monthly charges are:" + budget);
			System.out.println("Semi year charges are : " + semi);
			System.out.println("Annual year charges are : " + annual);
		} else if (name.equals(s3)) {
			int budget = 150;
			int semi = (budget * 6) - budget;
			int annual = (budget * 12) - (2 * budget);
			System.out.println("Hathway charges are");
			System.out.println("monthly charges are:" + budget);
			System.out.println("Semi year charges are : " + semi);
			System.out.println("Annual year charges are : " + annual);
		} else {
			System.out.println("No networks are there as per your interest");
		}
	}

}
