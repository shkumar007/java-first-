package util;
import java.util.*;
public class Sring {
	public static void main(String[] args)
	{
		char a[]=new char[30];
	     String k[];
	     //StringBuffer sb=new StringBuffer();
		String s="    Hyderabad is very polluted      ".trim();
		String s1="H";
		String s2="yd";
		String s3="erabad";
		String s4=s1+s2+s3;//adding of strings
		
		StringBuffer sb=new StringBuffer(s);
		//sb.insert(0, "hello ");
		//sb.reverse();
		//sb.delete(0, 5);
		//sb.append(" hello");
		//String z=sb.toString();
		
		
		
		//int m=s4.length();//finding length() of string
		//char x=s4.charAt(5);//String.charAt(index value)
		//int z=s4.compareTo(s1);
		//int z=s4.compareToIgnoreCase(s2);
		//boolean z=s4.equals(s4);
		//boolean z=s4.equalsIgnoreCase(s);
		//boolean z=s4.startsWith(s2);
		//boolean z=s4.endsWith(s);
		//int z=s4.indexOf(s1);
		//int z=s4.lastIndexOf(s1);
		//String z=s4.replace('a', 'z');
		//String z=s4.substring(5);
		//String z=s4.substring(2,5);
		//String z=s4.toLowerCase();
		//String z=s4.toUpperCase();
		//String z=s.trim();
		
		//s.getChars(2, 22, a, 0);
		
		/*k=s.split(" ");
		for(int i=0;i<k.length;i++)
		System.out.println(k[i]);*/
		
		
		String h= new String("Hyderabad");
		if(s4==h)
			System.out.println("same");
		else
			System.out.println("not same");
		//sb.append("Hai");
		//sb.insert(0,"Hai");
		//sb.delete(0,2);
		//int n=sb.indexOf("very");
		//int n=sb.lastIndexOf("is");
		//sb.replace(0, 5, "hhhh");
		//String z=sb.substring(5);
		//String z=sb.substring(1,12);
				//System.out.println(z);
	}

}
