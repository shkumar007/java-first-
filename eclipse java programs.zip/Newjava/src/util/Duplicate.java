package util;

import java.util.Scanner;

public class Duplicate {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of array :");

		int a[] = new int[sc.nextInt()];
		for (int i = 0; i < a.length; i++) {
			System.out.println("enter index value " + i + " is :");
			a[i] = sc.nextInt();
		}

		Duplicate obj = new Duplicate();
		obj.duplicate(a);

	}

	public static void duplicate(int[] m) {

		int count = 0;
		for (int i = 0; i < m.length - 1; i++) {
			for (int j = i + 1; j < m.length; j++) {
				if (m[i] == m[j] && i != j /* && i<j&& count<=1 */) {
					 count++;

					// if (count>1) {
					// m[i]=0;
					System.out.println(m[j]+":::::::::"+count);
				}
			}
		}
	}

}
