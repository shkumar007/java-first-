package util;

public class ReverseArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int s[]= {1,2,3,4,5,6,7,8,9};
		int v[]=new int[s.length];
		for (int i = 0,j=s.length-1;j>=0;j--, i++) {
				
			v[i]=s[j];
		}
		for(int m:v)
		System.out.println(m);
		
	}

}
