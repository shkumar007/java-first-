package util;

import java.util.Scanner;

public class Findingsamevalueinarray {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("enter the size of 1 array : ");
		int size1 = sc.nextInt();
		int a[] = new int[size1];
		System.out.println("enter elements in to array :");
		for (int i = 0; i < a.length; i++) {

			a[i] = sc.nextInt();
		}
		System.out.println("enter the size of 2  array : ");
		int size2 = sc.nextInt();
		int b[] = new int[size2];
		System.out.println("enter elements in to 2 array :");
		for (int i = 0; i < b.length; i++) {

			b[i] = sc.nextInt();
		}
		int size3 = 0;
		if (size1 > size2)
			size3 = size1;
		else
			size3 = size2;

		int c[] = new int[size3];
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < b.length; j++) {

				if (a[i] == b[j])
					c[i] = a[i];
			}

		}
		for (int i = 0; i < c.length; i++) {

			System.out.println("are:" + c[i]);

		}

	}

}
