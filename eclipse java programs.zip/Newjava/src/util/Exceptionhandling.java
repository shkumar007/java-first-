package util;
public class Exceptionhandling {
	public static void main(String[] args)  {
		int x=5,y=0;
		try {
		System.out.println((float)x/y);
		int b[]= {1,2,3,6,5,4};
          b[20]=90;			
		}
		catch(Exception e) {
			System.out.println(e);	
		}
	}
}
