package util;

import java.util.Scanner;

public class Fibonacci {

	// public static void main(String[] args) {
	/*
	 * factorial number series int num =new Scanner(System.in).nextInt();
	 * System.out.println("factorial of "+num+"  is :"); int x=1; while(num!=0)
	 * {x=x*num; num--;
	 * 
	 * } System.out.println(x);
	 */
	/*
	 * palindrome number and reverse an number int num =new
	 * Scanner(System.in).nextInt();
	 * 
	 * System.out.println("reverse of " + num + " is:"+ r(num));
	 * 
	 * int m=r(num); if(num==m) { System.out.println(num+ " is palindrome"); }else
	 * {System.out.println(num+ " is not palindrome"); } } public static int r(int
	 * num) {
	 * 
	 * int x=0; int y=0; do { x=num%10; y=y*10+x; num=num/10; }while(num>0); return
	 * y; }
	 */
	/*
	 * //Arm strong number int num =new Scanner(System.in).nextInt();
	 * 
	 * System.out.println("arm strong of " + num + " is:"+ arm(num));
	 * 
	 * 
	 * } public static int arm(int num) {
	 * 
	 * int x=0; int y=0; do { x=num%10; y=y+x*x*x; num=num/10; }while(num>0); return
	 * y;
	 * 
	 * }
	 */

	/*
	 * //gcd int num1 =new Scanner(System.in).nextInt(); int num2 =new
	 * Scanner(System.in).nextInt();
	 * 
	 * System.out.println("gcd of " + num1 + " and "+num2+ " is:" +gcd(num1,num2));
	 * 
	 * 
	 * } public static int gcd(int num1,int num2) { if(num2==0) { return num1; }
	 * 
	 * return gcd(num2 , num1%num2); }
	 * 
	 */

	// Java program to find missing Number

	/*
	 * public static void main(String[] args) { int a[]= {0,2,4,6,10};
	 * System.out.println(getmissing(a,5));
	 * 
	 * 
	 * } static int getmissing(int a1[],int n) {
	 * 
	 * int x1 = a1[0]; int x2 = 1; for (int i = 1; i < n; i++) x1 = x1 ^ a1[i]; for
	 * (int i = 2; i <= n+1; i++) x2 = x2 ^ i;
	 * 
	 * return (x1 ^ x2); }
	 * 
	 * 
	 * 
	 */

}
