//Ascending and Descending
package util;
import java.util.Scanner;
public class Ascendingorder {

	public static void main(String[] args) 
	{
		/*//Ascending and Descending
		Scanner sc=new Scanner(System.in);
		System.out.println("Eneter number : ");
		int a =sc.nextInt();
		int n[]=new int[a];
		for(int b=0;b<a;b++)
		{
			System.out.println("Enter numbers : ");
			n[b]=sc.nextInt();
		}
		int l=a-1;
		
		int temp;
		for(int i=0;i<l;i++)
		{
			for(int j=0;j<l-i;j++)
			{
				if(n[j]<n[j+1])
				{
					temp =n[j];
					n[j]=n[j+1];
					n[j+1]=temp;
					
				}
			}
		
		}
		System.out.println("sorted array is");
		for(int h:n)
			System.out.println(h);*/
		/*
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the no of subjects : ");
		int n=sc.nextInt();
			System.out.println("Enter English marks : ");
		    float a=sc.nextFloat();
		    
		    System.out.println("Enter telugu marks : ");
		    float b=sc.nextFloat();
		    System.out.println("Enter social marks : ");
		    float c=sc.nextFloat();
		    System.out.println("Enter Maths marks : ");
		    float d=sc.nextFloat();
		    System.out.println("Enter science marks : ");
		    float e=sc.nextFloat();
	        if(a<35){System.out.println("English got failed ");}
		    if(b<35) {System.out.println("telugu got failed ");}
		    if(c<35) {System.out.println("social got failed ");}
		    if(d<35) {System.out.println("Maths got failed ");}
		    if(e<35) {System.out.println("science got failed ");}
		float sum=a+b+c+d+e;
		double average=sum/n;
		System.out.println("Total marks are : " +sum);
		System.out.println("Percentage is : " +average);*/
	
	
		
		/*Scanner sc= new Scanner(System.in);
		System.out.println("enter: ");
		int n=sc.nextInt();
		int [] m=new int[n];
		int s=0;
		for (int i = 0; i < m.length; i++) {
			System.out.println("enter marks :");
		m[i]=sc.nextInt();
		}
		for (int k = 0; k < m.length; k++) {
			
		
if(m[k]<35)
{
	s=1;
}}
	if(s==1) {System.out.println("you are fail");}
	else {System.out.println("you are passes");}
		*/
		
		
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("pl enter string : ");
        String s=sc.nextLine().toLowerCase();
		//String s=sc.nextLine().toUpperCase();
		
		int h=0;
			for (int i = 0; i < s.length(); i++) {
				if(s.charAt(i)=='a' || s.charAt(i)=='e' || s.charAt(i)=='i' || s.charAt(i)=='o' ||s.charAt(i)=='u' )
			{h=h+1;
				System.out.println (" "+s.charAt(i));
			}
			}
		System.out.println("vowels count are : "+h);
		
		*/
		/*
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the size : ");
		int n=sc.nextInt();
		int a[]=new int[n];
		int s=0,m=0;
		for (int i = 0; i < a.length; i++)
		
		 
		 {
			System.out.println("enter a["+i+"] value");
			a[i]=sc.nextInt();
		}
		
		
		for(int k:a) {
		if(k%2==0)
			s=s+k;
		else 
			m=m+k;}
		System.out.println("sum of even numbers are :"+s);
		System.out.println("sum of odd numbers are :"+m);
		
		*/
		
/*		Scanner sc=new Scanner(System.in);
		String s[]= {"tel" , "eng","math","sci","social"};
		System.out.println("enter subjects no of :");
		int n=sc.nextInt();
		int a[]=new int[n];
		float x=0;
		for (int i = 0; i < a.length; i++) {
			System.out.println("enter " +s[i]+ " marks : "  );
			a[i]=sc.nextInt();
			}
		for (int k = 0; k < a.length; k++) {
			if(a[k]<35)
			 {   
				System.out.println("you are fail in " + s[k] + " subject");
			 }
			else
				{
				System.out.println("you are passed in " + s[k] + " subject");	
				}
				}
		
		for(int h:a)
		{
		    x=x+h;	
		}
		
		System.out.println("total marks are : "+x);
		System.out.println("percentage : "+(x/5));*/

	/*Scanner sc=new Scanner(System.in);
		System.out.println("enter size of array :");
		int n=sc.nextInt();
		int a[]=new int[n];
		int m=0;
		for (int i = 0; i < a.length; i++) {
			System.out.println("enter a["+i+"] value : "  );
			a[i]=sc.nextInt();
			}
	for(int h:a)
	{
		m=m+h;
	}
	System.out.println("sum of array : " +m);
	System.out.println("----------------");
	for (int k = 0; k < a.length; k++) {
		System.out.println("subtraction " +a[k]+ " from sum :" +m);
	
		m=m-a[k] ;
	//System.out.println("subtraction " +a[k]+ " from sum :" +m);
	}
	System.out.println("----------------------");
	System.out.println("subtraction of array : "+m);
	
	*/
		Scanner sc=new Scanner(System.in);
		char v[]= {'a','e','i','o','u'};
		System.out.println("enter string :");
		String s=sc.next();
		sc.close();
		for (int i = 0; i < s.length(); i++) 
		{
			for (int j = 0; j < v.length; j++) 
			{
			if(s.charAt(i)==v[j])
			{
				
				System.out.println(s.charAt(i));
			}
			
			
		}
		}
	
	

	
	}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
	
	
	
}
