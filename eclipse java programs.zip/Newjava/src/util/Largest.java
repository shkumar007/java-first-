package util;

public class Largest {

	public static void main(String[] args) {
		int a[]= {10,-100,200,303,-4000,5,6};
		int m=a[0];
		for (int i = 0; i < a.length; i++) {
			if(m>a[i])
				m=a[i];
				
		}
		System.out.println(m);

	}

}
