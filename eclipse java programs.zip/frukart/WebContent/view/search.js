function searchText() {
	var search = document.getElementById("search").value;
	var xhr = new XMLHttpRequest();
	var url = "http://localhost:8080/frukart/searchservlet?search=" + search;
	var finalarr = [];
	var arr = [];
	xhr.open("get", url, true);
	xhr.onreadystatechange = function() {
		if (xhr.readyState == 4 && xhr.status == 200) {
			var respText = xhr.responseText;
			
			respText = respText.substring(20, respText.length - 1);
			var array_mama = respText.split(",");

			for (let i = 0; i < array_mama.length; i++) {

				var obj = JSON.parse(array_mama[i]);
				arr.push(obj.fname);
			}

			for (let i = 0; i < arr.length; i++) {

				var temp = arr[i];
				if (temp.search(search) > -1) {
					finalarr.push(temp);
				}
			}
			
			if(search.length == 0){
				finalarr=[];
				var p = document.getElementsByTagName("p");
				for (i = 0; i < p.length; i++) {
					p[i].style.display = "none";
				}
			}
			console.log("final ----------------->" + finalarr);

			if (finalarr.length > 0) {
				var p = document.getElementsByTagName("p");
				for (i = 0; i < p.length; i++) {
					p[i].style.display = "none";
				}
				for (var i = 0; i < finalarr.length; i++) {
					document.getElementById("result").style.display = "block";
					var l = document.createElement("p");
					l.innerText = finalarr[i];
					document.getElementById("result").appendChild(l);
				}
			}

			/*if ((respText.length) != 0) {
				document.getElementById('result').style.display = 'block';
				var str = xhr.responseText.split("\n");
				var items;
				for (i = 0; i < str.length - 1; i++) {
					items = '<div ="setText(this.innerHTML);" ';
					items += '>' + str[i] + '</div>';
					result.innerHTML += items;

				}
			} else {
				document.getElementById('result').style.display = 'none';
			}*/
		}
	};
	xhr.send(null);
}






/*
 * function ivvubay(search){ var xhr = new XMLHttpRequest(); var url =
 * "http://localhost:8080/frukart/searchservlet?search=" + search;
 * xhr.open("get", url, true); xhr.onreadystatechange = function() {
 * console.log("nenu unnaaaa"); if (xhr.readyState == 4 && xhr.status == 200) {
 * let respText = xhr.responseText; console.log("respppppppppppppppp"+respText)
 * return respText; } }; }
 */
