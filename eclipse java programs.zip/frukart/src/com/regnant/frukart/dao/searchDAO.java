package com.regnant.frukart.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class searchDAO {

	public static List<String> getsearchdata() throws ClassNotFoundException, SQLException {

		List<String> searchlist = new ArrayList<>();

		Connection con = DbConnection.getConnection();
		Statement stmt = con.createStatement();

		String sqlquery = "select * from frukart.productdetails;";

		ResultSet rsd = stmt.executeQuery(sqlquery);

		while (rsd.next()) {
			String fname = rsd.getString(4);
			searchlist.add(fname);
		}

		
		return searchlist;

	}

}
