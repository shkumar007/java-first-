package com.regnant.frukart.beans;

public class UserBean {

	private String name;
	private String pwd;
	private String phoneNum;
	private String emailId;
	
	public UserBean(String name, String pwd,  String emailId, String phoneNum) {
		this.name = name;
		this.emailId = emailId;
		this.pwd = pwd;
		this.phoneNum = phoneNum;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	
	
}
