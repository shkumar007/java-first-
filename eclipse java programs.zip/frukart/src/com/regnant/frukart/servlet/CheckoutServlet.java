package com.regnant.frukart.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.regnant.frukart.dao.OrderDAO;

/**
 * Servlet implementation class Billingservlet
 */
@WebServlet("/CheckoutServlet")
public class CheckoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CheckoutServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println("billing");
		HttpSession session = request.getSession();
		@SuppressWarnings("unchecked")
		Set<Map<String, String>> li = (Set<Map<String, String>>) session.getAttribute("addproducts");
		if (li != null) {
			for (Map<String, String> fruit : li) {
				String fruitname = fruit.get("name");
				String quantity = "1";
				String email = (String) session.getAttribute("email");
				String price = fruit.get("price");
				String picname = fruit.get("pic");
				System.out.println(email);

				try {
					OrderDAO.placeOrder(email, fruitname, quantity, picname, price);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			session.setAttribute("addproducts", new HashSet<Object>());
			RequestDispatcher rd = request.getRequestDispatcher("/view/orderConfrmation.jsp");
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
