package com.regnant.frukart.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.regnant.frukart.dao.ProductDAO;

/**
 * Servlet implementation class CartSessionServlet
 */
@WebServlet("/CartSessionServlet")
public class CartServlet extends HttpServlet {
	private static final String DECREMENT_QNT = "subitem";
	private static final String INCREMENT_QNT = "additem";
	private static final String REMOVE_ITEM = "removeitem";
	private static final String ADD_PRODUCTS = "addproducts";
	private static final String ADD_TO_CART = "addtocart";
	private static final String TASK = "task";
	private static final String ID = "id";
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CartServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		String task = request.getParameter(TASK);
		String product_id = request.getParameter(ID);
		System.out.println("id--> task-->" + product_id + " " + task);
		HttpSession session = request.getSession();
		Set<Map<String, String>> productSet = null;
		if (task.equals(ADD_TO_CART)) {
			productSet = (Set<Map<String, String>>) session.getAttribute(ADD_PRODUCTS);
			if (productSet == null) {
				productSet = new HashSet<>();
				addProduct(product_id, session, productSet);
			} else {
				addProduct(product_id, session, productSet);
			}
		} else if (task.equals(REMOVE_ITEM)) {
			productSet = removeProdct(session, product_id);
		} else if (task.equals(INCREMENT_QNT)) {
			productSet = increamentQnt(session, product_id);
		} else if (task.equals(DECREMENT_QNT)) {
			productSet = decrimentQnt(session, product_id);
		}
		System.out.println(productSet);
		session.setAttribute(ADD_PRODUCTS, productSet);
		RequestDispatcher rd = request.getRequestDispatcher("/view/AddToCart.jsp");
		rd.forward(request, response);
	}

	@SuppressWarnings("unchecked")
	private Set<Map<String, String>> decrimentQnt(HttpSession session, String id) {
		Set<Map<String, String>> productSet = (Set<Map<String, String>>) session.getAttribute(ADD_PRODUCTS);
		for (Map<String, String> product : productSet) {
			if (product.get(ID).equals(id)) {
				if (product.get("count").equals("1")) {
					productSet.remove(product);
				} else {
					product.put("count", "" + (Integer.parseInt(product.get("count")) - 1));
				}
				break;
			}
		}
		System.out.println(productSet);
		return productSet;
	}

	@SuppressWarnings("unchecked")
	private Set<Map<String, String>> increamentQnt(HttpSession session, String id) {
		Set<Map<String, String>> productList = (Set<Map<String, String>>) session.getAttribute(ADD_PRODUCTS);
		for (Map<String, String> product : productList) {
			if (product.get(ID).equals(id)) {
				product.put("count", "" + (1 + Integer.parseInt(product.get("count"))));
			}
		}
		System.out.println(productList);
		return productList;
	}

	@SuppressWarnings("unchecked")
	private Set<Map<String, String>> removeProdct(HttpSession session, String id) {
		Set<Map<String, String>> productList = (Set<Map<String, String>>) session.getAttribute(ADD_PRODUCTS);
		for (Map<String, String> product : productList) {
			if (product.get(ID).equals(id)) {
				productList.remove(product);
			}
		}
		System.out.println(productList);
		return productList;
	}

	private void addProduct(String id, HttpSession session, Set<Map<String, String>> addedProducts) {
		try {
			Map<String, String> product = ProductDAO.getProductById(id);
			product.put("count", "1");
			addedProducts.add(product);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

}
