package com.regnant.frukart.listners;

import java.sql.SQLException;
import java.util.EmptyStackException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import com.regnant.email.EmailUtils;
import com.regnant.frukart.dao.ProductDAO;
import com.regnant.frukart.dao.ProfileDAO;
import com.regnant.frukart.utils.Constants;

/**
 * Application Lifecycle Listener implementation class SessionInvalidateListener
 *
 */
@WebListener
public class SessionInvalidateListener implements HttpSessionListener {

    /**
     * Default constructor. 
     */
    public SessionInvalidateListener() {
        // TODO Auto-generated constructor stub
    	System.out.println("SessionInvalidateListener.SessionInvalidateListener()");
    }

	/**
     * @see HttpSessionListener#sessionCreated(HttpSessionEvent)
     */
    public void sessionCreated(HttpSessionEvent se)  { 
         // TODO Auto-generated method stub
    	System.out.println("SessionInvalidateListener.sessionCreated()");
    }

	/**
     * @see HttpSessionListener#sessionDestroyed(HttpSessionEvent)
     */
    @SuppressWarnings("unlikely-arg-type")
	public void sessionDestroyed(HttpSessionEvent se)  {
    	System.out.println("SessionInvalidateListener.sessionDestroyed()");
         // TODO Auto-generated method stub
    	Set<Map<String, String>> annonymouscart=new HashSet<>();
    	Map<String,String> cart = new HashMap<>();
    	HttpSession session = se.getSession();
    	Set<Map<String, String>> addedProducts =(Set<Map<String, String>>) session.getAttribute("addproducts");
    	addedProducts.stream().forEach((productMap)->{
    		System.out.println("Store Product while destroying->");
    		productMap.entrySet().stream().forEach((entry)->{
    			System.out.print(entry.getKey() + "=" + entry.getValue() + " ");
    			cart.put(entry.getKey(), entry.getValue());
    			
    		});
    		annonymouscart.add(cart);
    		String email = (String)session.getAttribute(Constants.EMAIL);
    		System.out.println(email);
    		try {
				ProductDAO.anonymous(annonymouscart,email);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException |EmptyStackException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    	
    		
    	});
    	
    }
	
}
