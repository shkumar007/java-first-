package com.regnant.frukart.utils;

public class SqlConstants {

}
