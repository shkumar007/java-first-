package Stringlabprograms;
import java.util.Scanner;
public class Findingduplicatecharacersinstring {
	public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			System.out.println("enter the string : ");
			String s=sc.nextLine();
			
			String temp = getnonrepeatedchars(s);
			sc.close();
		//	System.out.println(temp);
			//System.out.println(temp.charAt(1));
			
}

	private static String getnonrepeatedchars(String s) {
		int count=0;
		String temp="";
		for (int i = 0; i < s.length(); i++) {
			char ch1=s.charAt(i);
			for (int j = 0; j < s.length(); j++) {
				char ch2=s.charAt(j);
				if(ch1==ch2)
				
				{count=count+1;
				
					}
				
				}
			
		if(temp.indexOf(ch1)<0 /*&& count==1 && count >1*/)
		{
			temp=temp+ch1;
			
			System.out.println(ch1+":"+count);
		}
		count=0;
		
		}
		return temp;
	}
}