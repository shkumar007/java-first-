package Stringlabprograms;

public class main_class_for_reverse_a_string_using_stack {

	public static void main(String[] args) {
String str = "hemanth";
String m="";
		Reverse_a_string_usingstack obj=new Reverse_a_string_usingstack();
		for (int i = 0; i <str.length(); i++) {
			obj.push(str.charAt(i));
		}
		
		for (int i = 0; i <str.length(); i++) {
			
		
		
		m=m+(char)obj.pop();
		}
		
		//obj.show();
		System.out.println(m);
	}

}
