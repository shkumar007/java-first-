package Stringlabprograms;
public class Find_substring_in_a_string {
	public static void main(String[] args) {
		String str="amma".trim().toLowerCase();
System.out.println("Sub strings in a string are : ");
		for (int i = 0; i < str.length(); i++) {
			for (int j = 1; j <str.length()-i; j++) {
			System.out.println(str.substring(i,i+j));
			}
		}
	}
}
