package Stringlabprograms;

public class Insert_substring_in_main_string {

	public static void main(String[] args) {

		String main_string="hello world is robo 2.0 reloaded";
		String sub_string=" this";
		String m="";
	for (int i = 0; i < main_string.length(); i++) {
		
		if(i==11) {
			m=m+sub_string;
		}
		
		
		
		m=m+main_string.charAt(i);
	}
System.out.println(m);		
		/*StringBuffer sb= new StringBuffer(main_string);		
		System.out.println(sb.insert(11, sub_string));*/
		
	}

}
