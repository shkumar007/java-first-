package Stringlabprograms;

import java.util.Scanner;

public class Palindromeofstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("please enter the name : ");
String name=sc.nextLine();
sc.close();
reverseofstring(name);

	}
	public static void reverseofstring(String name) {
		String temperaryname="";
			for (int i =(name.length()-1) ; i >=0; i--) {
				temperaryname+=name.charAt(i);
			}
			if (temperaryname.equals(name)) {
				System.out.println("Given string is palindrome");
			} else {
				System.out.println("Given string is not palindrome");
		
			}
	}

}
