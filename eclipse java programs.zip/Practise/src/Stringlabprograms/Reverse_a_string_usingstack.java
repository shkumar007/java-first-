package Stringlabprograms;



public class Reverse_a_string_usingstack {

		char array[]=new char[10];
		int cursor=0;
		public void push(char data)   {
			
			if(cursor==10) {
				System.out.println("stack if full");
			}
			
			else {
			array[cursor]=data;
			cursor=cursor+1;
			}
		}
		
		public int pop()
		{char data=' ';
			if(isEmpty()) {
				System.out.println("stack is empty");
			}
			
			else
			{
			cursor=cursor-1;
			 data=array[cursor];
			array[cursor]=' ';
			}
			return data;	
		}
		public boolean isEmpty() {

			return cursor<=0;
		}
		
		
		
		
}
