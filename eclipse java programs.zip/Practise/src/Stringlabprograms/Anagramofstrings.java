package Stringlabprograms;

import java.util.Arrays;

public class Anagramofstrings {

	public static void main(String[] args) {

		String s1 = "from".toLowerCase();
		String s2 = "form".toLowerCase();
		char[] s1array = s1.toCharArray();
		char[] s2array = s2.toCharArray();
//		Arrays.sort(s1array);
//		Arrays.sort(s2array);

		s1array=arraysorting(s1array);
		s2array=arraysorting(s2array);
		

/*		for (int m = 0; m < s2array.length; m++) {

			char temp1;
			for (int k = 0; k < s2array.length; k++) {

				if (s2array[m] > s1array[k]) {
					temp1 = s2array[m];
					s2array[m] = s2array[k];
					s2array[k] = temp1;

				}
			}
		}*/

		String one = new String(s1array);

		String two = new String(s2array);

		System.out.println(one);
		System.out.println(two);

//				boolean a = Arrays.equals(s1array, s2array);
//				if (a) {
//					System.out.println("strings are anagram strings");
//
//				} else {
//					System.out.println("strings are not anagrams");
//				}
	}

	public static char[] arraysorting(char[] s1array) {
		for (int i = 0; i < s1array.length; i++) {

			char temp;
			for (int k = 0; k < s1array.length; k++) {

				if (s1array[i] < s1array[k]) {
					temp = s1array[i];
					s1array[i] = s1array[k];
					s1array[k] = temp;

				}
			}

		}

		return s1array;
	}

}
