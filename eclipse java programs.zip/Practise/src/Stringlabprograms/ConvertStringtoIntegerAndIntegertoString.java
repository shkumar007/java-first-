package Stringlabprograms;

import java.util.Scanner;

public class ConvertStringtoIntegerAndIntegertoString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
//System.out.println("enter the string : ");
//String str=sc.nextLine();
//charstoint(str);
System.out.println("enter integers ");
int arraysize=sc.nextInt();
int arrayofintegers[]=new int[arraysize];

String s="";
for (int i = 0; i < arraysize; i++) {
	System.out.println("enter value");
	arrayofintegers[i]=sc.nextInt(); sc.close();
	s=s+(char)arrayofintegers[i];
}
System.out.println(s);


	}
//characters to string
	private static void charstoint(String str) {
		char chararrayfornumbertostring[]=new char[str.length()];
		char chararray[] =str.toCharArray();
		int intarray[]=new int[chararray.length];
		for (int i = 0; i < chararray.length; i++) {
			System.out.print((int)chararray[i]+" ");
		}
	}














}
