package Stringlabprograms;

import java.util.Scanner;

public class Countnoofvowelsandconsonents {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
Scanner sc=new Scanner(System.in);
System.out.println("enter the string :");
String name=sc.nextLine();
sc.close();
int vowelscount=0,consonentscount=0;
for (int i = 0; i < name.length(); i++) {
	if(name.charAt(i)=='a' || name.charAt(i)=='e' || name.charAt(i)=='i' || name.charAt(i)=='o' || name.charAt(i)=='u') {
		vowelscount=vowelscount+1;
	}
	else if(name.charAt(i) !=' ')
	{
		consonentscount+=1;
	}
}

System.out.println("vowels count present in string are : "+vowelscount);
System.out.println("consonents count present in string are : "+consonentscount);

	}

}
