package Stringlabprograms;

import java.util.Scanner;

public class Stringtouppercase {

	public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
System.out.println("Enter the string");
String str=sc.nextLine();
sc.close();
System.out.println(str.toUpperCase());
		
		
	}

}
