package Stringlabprograms;

public class Swappingoftwostrings {

	public static void main(String[] args) {

		String mainstring="hello mama";
		String swappedstring="";
		String tempstring[]=mainstring.split(" ");
		for (int i = tempstring.length-1; i >=0 ; i--) {
			swappedstring+=tempstring[i]+" ";
		}
		System.out.println(swappedstring);
		
	}

}
