package Stringlabprograms;

import java.util.Scanner;

public class Stringtolowercase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("Enter the string");

System.out.println(sc.nextLine().toLowerCase().trim());

	}

}
