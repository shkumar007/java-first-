package Stringlabprograms;

public class Findduplicatewordsinstringandcount {

	public static void main(String[] args) {

		String input="hello mama akkada ra hello hello"; 		
		String[] wordsinstring=input.split(" ");	
		int wordcount=1;							
		
		for(int i=0;i<wordsinstring.length;i++)		
		{
			for(int j=i+1;j<wordsinstring.length;j++)	
			{
				
			if(wordsinstring[i].equals(wordsinstring[j]))	
				{
					wordcount=wordcount+1;				
					wordsinstring[j]="0";			
				}
			}
			if(wordsinstring[i]!="0") 
			System.out.println(wordsinstring[i]+" : "+wordcount);	
			wordcount=1;
	}
	}

}
