package Stringlabprograms;

public class Deletealloccurencesofcharacter_in_string {

	public static void main(String[] args) {

		String name="hello world this is robo 2.0 reloaded";
		char character_to_be_deleted='e';
		String name2="";
		for (int i = 0; i < name.length(); i++) {
			if(name.charAt(i)!=character_to_be_deleted) {
				name2=name2+name.charAt(i);
			}
			
		}
		
		System.out.println(name2);
		
		
	}

}
