package Stringlabprograms;

public class TotalNumberOfOccurrencesOfGivenCharacterInStringWithoutLoop {

	public static void main(String[] args) {
		
String content="hello bava akkada";

int count=(content.length())-(content.replace("a", "").length());

System.out.println("number of characters A in string is : "+ count);
	}

}
