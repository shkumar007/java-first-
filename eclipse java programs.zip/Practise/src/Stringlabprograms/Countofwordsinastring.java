package Stringlabprograms;

import java.util.Scanner;

public class Countofwordsinastring {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter string : ");
		String str=sc.nextLine();sc.close();
		String arr[]=str.split(" ");
		System.out.println(arr.length);
		
		
		
	}

}
