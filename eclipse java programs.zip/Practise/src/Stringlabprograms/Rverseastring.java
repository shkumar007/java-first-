package Stringlabprograms;

public class Rverseastring {

	public static void main(String[] args) {

		String name="hello mama";
		String newname="";
		for (int i = name.length()-1; i >=0 ; i--) {
			
			newname+=name.charAt(i);
		}
		System.out.println("reverse of a string is : "+newname);
		
		
	}

}
