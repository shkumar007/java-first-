package Stringlabprograms;

public class Deletecharactersfromposition {

	public static void main(String[] args) {

		String name="0123456789";
		int position=2;
		int noof_charactersto_delete=8;
		String m="";
		for (int i =0; i < name.length(); i++) {
			if(i>=position && i<=noof_charactersto_delete)
				continue;
			
				m=m+name.charAt(i);
				
				
			}
		System.out.println(m);
		
		
	}

}
