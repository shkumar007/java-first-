package Stringlabprograms;

public class Comparetwostrings {

	public static void main(String[] args) {

	String s1="hello world";
	String s2="hello mama";
	int x=s1.compareTo(s2);
	if(x>0) {
	System.out.println("s1 is greater than s2");
	}
	else if(x<0) {
		System.out.println("s1 is smaller than s2");
	}
	else {
		System.out.println("both are equal");
	}
	
	
	}

}
