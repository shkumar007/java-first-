package Arraylabprograms;

public class Print_even_and_odd_numbers_of_array {

	public static void main(String[] args) {

		int a[]= {1,2,3,4,5,6,7,8,9};
		String even="";
		String odd="";
		for (int i = 0; i < a.length; i++) {
			if(a[i]%2==0) {
				even=even+a[i]+" ";
			}
			else
			{
				odd=odd+a[i]+" ";
			}
		}
		System.out.println("even elements in array are : "+even);
		System.out.println("odd elements in array are : "+odd);
		
	}
}
