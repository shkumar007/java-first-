package Arraylabprograms;

public class Find_index_of_given_element {

	public static void main(String[] args) {

		int a[]= {1,2,3,4,6,7,8,9};
		int number=2;
		for (int i = 0; i < a.length; i++) {
			if(a[i]==number) {
				System.out.println("Index value of a given element is : " +i);
			}
		}
		
		
	}

}
