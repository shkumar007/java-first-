package Arraylabprograms;

public class CalculateSumAndAverageOfArray {

	public static void main(String[] args) {

		int a[]= {1,2,3,4,5,6,7,8,9};
		int m=0;
		for (int i = 0; i < a.length; i++) {
			m=m+a[i];
		}
		System.out.println("Sum of Elelments in array are : "+m);
		System.out.println("Average of elements in array are : "+(m/a.length));
		
	}

}
