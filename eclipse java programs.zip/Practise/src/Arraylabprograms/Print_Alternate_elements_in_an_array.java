package Arraylabprograms;

public class Print_Alternate_elements_in_an_array {

	public static void main(String[] args) {

		int a []= {1,2,3,4,5,6,7,8,9};
		String alternate_numbers="";
		for (int i = 0; i < a.length; i++) {
			if(i%2==0)
			{
		alternate_numbers=alternate_numbers+a[i]+" ";		
			}
		}
		System.out.println("Alternate elements of an array are : "+alternate_numbers);
		
		
	}

}
