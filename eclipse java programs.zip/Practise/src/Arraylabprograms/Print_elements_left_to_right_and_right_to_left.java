package Arraylabprograms;

public class Print_elements_left_to_right_and_right_to_left {

	public static void main(String[] args) {

		int a[]= {1,2,3,4,5,6,7,8,9};
		String right_to_left=" ";
		String left_to_right=" ";
		for (int i = a.length/2; i >=0; i--) {
			right_to_left=right_to_left+a[i]+" ";
		}
		System.out.println("Elements right to left from middle"+right_to_left);
		for (int i = a.length/2; i < a.length; i++) {
			left_to_right=left_to_right+a[i]+" ";
		}
		System.out.println("Elements left to right from middle"+left_to_right);
	}

}
