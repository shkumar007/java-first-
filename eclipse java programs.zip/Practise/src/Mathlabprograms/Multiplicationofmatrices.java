package Mathlabprograms;

import java.util.Scanner;

public class Multiplicationofmatrices {

	public static void main(String[] args) {
		
	
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of row and column:");
		int rows=sc.nextInt();
		int coloumns=sc.nextInt();
		int firstmatrix[][]=new int[rows][coloumns];
		int secondMatrix[][]=new int[rows][coloumns];
		int outputMatrix[][]=new int[rows][coloumns];
		System.out.println("Please enter a number:");
		readmatrix(sc, rows, coloumns, firstmatrix);
		System.out.println("Please enter a number:");
		readmatrix(sc, rows, coloumns, secondMatrix);
	    System.out.println("Multiplication of arrays:");
		mutiplication(rows, coloumns, firstmatrix, secondMatrix, outputMatrix);
		System.out.println("Display the array:");
		
		displaymartix(outputMatrix);
		
		
	
		
	}

	private static void displaymartix(int[][] z) {
		for(int k[]:z)
		{
			for(int o:k)
			{
				System.out.print(o+"\t");
			}
			System.out.println();
		}
	}

	private static void mutiplication(int n, int m, int[][] x, int[][] y, int[][] z) {
		for(int i=0;i<n;i++)
		{
		for (int j=0;j<m;j++)
		{
		for(int k=0;k<n;k++)
		{
		z[i][j]=z[i][j]+x[i][k]*y[k][j];
		}
		}
		}
	}

	private static void readmatrix(Scanner sc, int n, int m, int[][] x) {
		for(int i=0;i<n;i++)
		{
		for (int j=0;j<m;j++)
		{
		x[i][j]=sc.nextInt();
		}
		}
	}
}
