package Mathlabprograms;

public class Maximumnumberintwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

byte num1=55;
byte num2=66;
if(num1>num2) {
	System.out.println(num1 + " is greater than "+ num2);
}
else
{
	System.out.println(num2 + " is greater than "+ num1);	
}
		
		
	}

}
