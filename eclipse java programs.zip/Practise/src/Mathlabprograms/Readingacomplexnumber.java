package Mathlabprograms;

import java.util.Scanner;

public class Readingacomplexnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("enter real number : ");

		double s=sc.nextDouble();
		System.out.println("enter the imaginary number");
		double m=sc.nextDouble();
		sc.close();
		System.out.println(s+"+"+m+"i");
		
	}

}
