package Mathlabprograms;

public class Areaandperimeterofrectangle {

	public static void main(String[] args) {
		
	int length=2;
	int width=2;
	if(length==width) {
		System.out.println("Perimeter of square is : "+(2*(length+width)));
		System.out.println("Area of square is : "+(length*width));
	}
	else {
		System.out.println("Perimeter of rectangle is : "+(2*(length+width)));
		System.out.println("Area of rectangle is : "+(length*width));
	}
	
	
	
	}

}
