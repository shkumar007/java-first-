package Mathlabprograms;
//area=(height*base)/2
public class Areaoftriangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int height=10;
int base=12;
System.out.println("Area of triangle is :  "+(height*base)/2);
		
		
	}

}
