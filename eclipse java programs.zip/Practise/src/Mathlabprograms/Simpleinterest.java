package Mathlabprograms;
//SIMPLE INTEREST=PTR/100;
public class Simpleinterest {

	public static void main(String[] args) {
	
		int P=1000;
		int R=2;
		
		int T=12;
		double A;
		
		A=(P*T*R)/100;
		System.out.println(A);

	}

}
