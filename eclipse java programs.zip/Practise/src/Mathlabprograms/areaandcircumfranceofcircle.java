package Mathlabprograms;

public class areaandcircumfranceofcircle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=1;
		System.out.println("area of circle is "+Math.PI*x*x);
System.out.println("circumfrance of circle is: " +2*x*Math.PI);
	}

}
