package Mathlabprograms;

public class Evaluatexpowern {
public static void main(String[] args) {
	int number=2;
	int exponent=-3;
	float temp=1;
	if(exponent>0) {
	for (int i = 1; i <=exponent; i++) {
		temp=temp*number;
	}
	System.out.println(temp);
	}
	else {
		for (int i = 1; i <=(-exponent); i++) {
			temp=temp*number;
		}
		System.out.println(1/temp);
		}
		
		
	}
	}

