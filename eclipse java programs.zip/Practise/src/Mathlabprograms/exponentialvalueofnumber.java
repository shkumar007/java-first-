package Mathlabprograms;

public class exponentialvalueofnumber {

	public static void main(String[] args) {
		
		
		double x=144;
	System.out.println(Math.exp(x));
		
		
		
	}

}
