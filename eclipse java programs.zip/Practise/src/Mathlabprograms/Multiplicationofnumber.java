package Mathlabprograms;

public class Multiplicationofnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int x=2;
		for (int i = 1; i < 11; i++) {
			System.out.println(x+" x "+i+" = "+(x*i));
		}
		
	}

}
