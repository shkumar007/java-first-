package Mathlabprograms;

public class Findingnumbernegorpos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x=0;
		if(x==0) {
			System.out.println("number is Zero");
		}
		else if(x>0) {
			System.out.println("number is +ve");
		}
		else {
			System.out.println("number is -ve");
		}
		
		
		
	}

}
