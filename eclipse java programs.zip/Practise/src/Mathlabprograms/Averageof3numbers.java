package Mathlabprograms;

public class Averageof3numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x=1,y=2,z=3;
		System.out.println("Average of 3 numbers are : "+(x+y+z)/2);
		
		
	}

}
