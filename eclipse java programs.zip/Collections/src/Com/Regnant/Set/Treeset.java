package Com.Regnant.Set;

import java.util.Iterator;
import java.util.SortedSet;
import java.util.TreeSet;

public class Treeset {
	public static void main(String[] args) {

		SortedSet<Integer> a = new TreeSet();

		a.add(1);
		a.add(2);
		a.add(3);
		a.add(-1);
		a.add(0);
		System.out.println(a.first());
		System.out.println(a.last());
		Iterator<Integer> it = a.iterator();
		while (it.hasNext()) {
			System.out.print(it.next() + " ");
		}

	}

}
