package Com.Regnant.Set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class HashSetInCollections {

	public static void main(String[] args) {

		
		
		Set <Integer> ar=new HashSet<Integer>();
		ar.add(5);
		ar.add(9);
		ar.add(22);
		ar.add(99);
		ar.remove(22);
		System.out.println(ar);
		
		Iterator<Integer> it = ar.iterator();
		while (it.hasNext()) {
			System.out.print(it.next() + " ");
		}
		
	}

}
