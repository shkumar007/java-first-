package Com.Regnant.Set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class LinkedHashSetInCollections {

	public static void main(String[] args) {

		
		Set <Integer> ar=new LinkedHashSet<Integer>();
		ar.add(5);

		ar.add(9);
		ar.add(22);
		ar.add(99);
		ar.add(9);
		//ar.remove(99);
		System.out.println(ar);
		
		/*Iterator<Integer> it = ar.iterator();
		while (it.hasNext()) {
			System.out.print(it.next() + " ");
		}*/
		
		
		
	}

}
