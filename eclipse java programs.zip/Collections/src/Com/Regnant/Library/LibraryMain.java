package Com.Regnant.Library;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LibraryMain {

	public static void main(String[] args) {
		Student[] students = null;
		Books[] book = null;
		ExecutorService executorService = Executors.newFixedThreadPool(FixedValues.no_of_students);

		try {
			book = new Books[FixedValues.no_of_books];
			students = new Student[FixedValues.no_of_students];
			for (int i = 0; i < FixedValues.no_of_books; i++) {
				book[i] = new Books(i);

			}

			for (int i = 0; i < FixedValues.no_of_students; i++) {
				students[i] = new Student(i, book);
				executorService.execute(students[i]);
			}
		} catch (Exception e) {
			e.printStackTrace();
			executorService.shutdown();
		} finally {
			executorService.shutdown();
		}

	}

}
