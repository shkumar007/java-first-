package Com.Regnant.Library;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Books {

	private int id;
	private Lock lock;

	public Books(int id) {
		super();
		this.id = id;
		this.lock = new ReentrantLock();

	}

	public void read(Student st) throws InterruptedException {
		lock.lock();
		System.out.println(st + " starts reading  " + this);
		Thread.sleep(2000);
		lock.unlock();
		System.out.println(st + " Finished reading  " + this);

	}

	@Override
	public String toString() {
		return " Book # " + id;
	}

}
