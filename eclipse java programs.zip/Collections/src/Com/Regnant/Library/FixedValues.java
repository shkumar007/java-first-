package Com.Regnant.Library;


public class FixedValues {

	public static int no_of_students = 5;
	public static int no_of_books =7 ;

	

	
}
