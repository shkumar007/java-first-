package Com.Regnant.Library;

import java.util.Random;

public class Student implements Runnable {

	private int id;
	private Books[] books;

	public Student(int id, Books[] books) {
		this.id = id;
		this.books = books;
	}

	@Override
	public void run() {

		Random ran = new Random();

		while (true) {
			int bookid = ran.nextInt(FixedValues.no_of_books);
			try {
				books[bookid].read(this);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return " Student # " + id;
	}

}
