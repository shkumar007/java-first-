package Com.Regnant.List;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ListIteratorInCollections {

	public static void main(String[] args) {

		List<String> ar = new ArrayList<String>();
		ar.add("hello");
		ar.add("world!!!!!!!!!!!!");
		ar.add("this ");
		ar.add("is");
		ar.add("robo");
		ar.add("new");
		ar.add("version");
		ar.add("reloaded to 2.0");
		System.out.println("Original array is : ");
		Iterator<String> it = ar.iterator();
		while (it.hasNext()) {
			System.out.print(it.next() + " ");
		}
		System.out.println();
		ListIterator<String> arr = ar.listIterator(ar.size());

		System.out.println("Modified array in reverse : ");
		while (arr.hasPrevious()) {
			System.out.print(arr.previous());
		}

	}

}
