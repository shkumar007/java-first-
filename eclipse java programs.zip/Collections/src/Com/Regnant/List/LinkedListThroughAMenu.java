package Com.Regnant.List;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;
import java.util.Stack;

public class LinkedListThroughAMenu {

	public static void main(String[] args) {

		List<Integer> ar = new LinkedList();
		int choice = 0;
		int  element;
		Scanner sc = new Scanner(System.in);
		while (choice < 4) {
			System.out.println("1.push");
			System.out.println("2.pop");
			System.out.println("3.replace");
			System.out.println("4.Eixt");
			choice = sc.nextInt();
			switch(choice) {
			case 1 :System.out.println("pls enter data to enter : ");
			element=sc.nextInt();
			ar.add(element);
			break;
			
			case 2:
				System.out.println("pl enter position of element to delete : ");
				int m = sc.nextInt();
				int m1=ar.remove(m-1);
				System.out.println("Deleted element in stack is :  " + m1);
				break;
			case 3:
				System.out.println("enter the position at which you want to replace : ");
				int position=sc.nextInt();
				
				System.out.println("pla enter the new element : ");
			element = sc.nextInt();
			System.out.println("element present at location is : " + ar.set(position-1,element));
			break; 
			case 4:
				System.exit(0);
				break;
			default:
				return;
			
			
			
			}
			
			System.out.println("content in lined list is :  " + ar);
			
		}
		
		
		
		
		
		
		
	}

}
