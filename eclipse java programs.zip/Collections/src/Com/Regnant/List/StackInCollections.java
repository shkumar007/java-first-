package Com.Regnant.List;

import java.util.Iterator;
import java.util.List;
import java.util.Stack;

public class StackInCollections {

	public static void main(String[] args) {

		Stack<String> ar = new Stack<String>();

		ar.push("hello");
		ar.push("mama");
		ar.push("akkada");
		//ar.pop();
		System.out.println(ar.peek());

		Iterator<String> it = ar.iterator();
		while (it.hasNext()) {
			System.out.print(it.next() + " ");
		}

	}

}
