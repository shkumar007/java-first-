package Com.Regnant.List;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Spliterator;

public class ArrayListInCollections {

	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		List<String> a = new ArrayList<String>();

		a.add("mamamama");

		List<String> ar = new LinkedList<String>();
		ar.add("hello");
		ar.add("world!!!!!!!!!!!!");
		ar.add("this ");
		ar.add("is");
		ar.add("robo");
		ar.add("is");
		ar.add("new");
		ar.add("version");
		ar.remove("is");
		ar.remove("new");
		
		 /* ListIterator<String> amm=ar.listIterator(); 
		  
		  amm.add("aaaaaa");
		  while(amm.hasNext())
		  { 
			  System.out.print(amm.next()+" ");
		  
		  }*/
		
		ListIterator<String> amm = ar.listIterator();
		amm.add("aaaaaa");
		for (int i = 0; i < ar.size(); i++) {
			System.out.print(ar.get(i) + " ");
		}
		

		

		System.out.println();

		long stopTime = System.currentTimeMillis();
		long elapsedTime = stopTime - startTime;
		System.out.println(elapsedTime);
//		ar.add("reloaded to 2.0");
//		ar.add(3, "bbbb");
//		ar.addAll(1, a);
//		System.out.println(ar.get(5));
//		System.out.println(ar.isEmpty());
//		System.out.println(ar.lastIndexOf("hello"));
//		ar.clear();
//		System.out.println(ar);
//		ar.remove(2);
//Object [] m=ar.toArray();
//
//for (Object object : m) {
//	System.out.print(object+" ");
//}
//System.out.println();

//	System.out.println(ar.remove("is"));
//	ar.removeAll(a);

//		MyOperator1<String> ooo=new MyOperator1();
//		ooo.mam="baba";
//		
// ar.replaceAll(ooo);
//ar.retainAll(ar);

//		Spliterator<String>m=ar.spliterator();
//		m.forEachRemaining((n) -> System.out.println(ar));
		/*
		 * List<String> arr = new ArrayList<String>(ar.subList(1,5)); Iterator it =
		 * arr.iterator(); while (it.hasNext()) { System.out.print(it.next() + " "); }
		 */

	}

}
