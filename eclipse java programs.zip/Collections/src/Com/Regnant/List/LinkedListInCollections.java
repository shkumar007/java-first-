package Com.Regnant.List;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class LinkedListInCollections {

	public static void main(String[] args) {
		/* long startTime = System.currentTimeMillis();
		List<String> ar = new LinkedList();
		ar.add("hello");
		ar.add("mama");
		ar.add("akkada");
		ar.add("ra");
		ar.add("ra");
		ar.add("ra");
		ar.add("babu");
		ar.remove("ra");
		ar.remove("mama");
		Iterator it = ar.iterator();
		while (it.hasNext()) {
			System.out.print(it.next() + " ");
		}
		System.out.println();
		long stopTime = System.currentTimeMillis();
	      long elapsedTime = stopTime - startTime;
	      System.out.println(elapsedTime);*/
		 long startTime = System.currentTimeMillis();
		
		 List<Integer> a = new LinkedList<Integer>();
		 for(int i=0;i<=100000;i++) {
			 a.add(i);
		 }
		 for (int i = 99999; i >=0 ; i--) {
			a.remove(i);
		}
		 
		System.out.println();
		long stopTime = System.currentTimeMillis();
	      long elapsedTime = stopTime - startTime;
	      System.out.println(elapsedTime);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}


