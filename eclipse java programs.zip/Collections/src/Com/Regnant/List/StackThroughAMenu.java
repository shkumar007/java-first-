package Com.Regnant.List;

import java.util.Scanner;
import java.util.Stack;

import javax.swing.plaf.synth.SynthSeparatorUI;

public class StackThroughAMenu {

	public static void main(String[] args) {

		Stack<Integer> ar = new Stack<Integer>();
		int choice = 0;
		int position, element;
		Scanner sc = new Scanner(System.in);
		while (choice < 1) {

			System.out.println("1.push");
			System.out.println("2.pop");
			System.out.println("3.search");
			System.out.println("4.Eixt");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("pls enter element : ");
				element = sc.nextInt();
				ar.push(element);
				break;
			case 2:
				int m = ar.pop();
				System.out.println("Deleted element in stack is :  " + m);
				break;

			case 3:
				System.out.println("which element to search : ");
				element = sc.nextInt();
				System.out.println("element present at location is : " + ar.search(element));
				break;

			case 4:
				System.exit(0);
				break;
			default:
				return;

			}

			System.out.println("content in stack is :  " + ar);

		}

	}

}
