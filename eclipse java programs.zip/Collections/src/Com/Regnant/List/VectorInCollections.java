package Com.Regnant.List;

import java.util.Iterator;
import java.util.Vector;

public class VectorInCollections {

	public static void main(String[] args) {

		
		Vector<String> ar=new Vector<String>();
		
		ar.add("mama");
		ar.add("akkada");
		System.out.println(ar.size());
		
		System.out.println(ar.get(1));
		ar.remove(1);
		
		Iterator it = ar.iterator();
		while (it.hasNext()) {
			System.out.print(it.next() + " ");
		}
		
		
	}

}
