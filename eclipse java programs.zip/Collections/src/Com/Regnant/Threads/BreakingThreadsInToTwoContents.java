package Com.Regnant.Threads;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class BreakingThreadsInToTwoContents {

	public static void main(String[] args) {
		Thread t1 = new Thread(new MultiThread());
		Thread t2 = new Thread(new MultiThread());
		Thread t3 = new Thread(new MultiThread());
		t1.start();
		t2.start();
		t3.start();
	}

}

class MultiThread implements Runnable {
	private static BufferedReader br = null;
	private List<String> list;

	static {
		try {
			br = new BufferedReader(new FileReader("F:\\package2\\One.txt"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void run() {
		String line = null;
		int count = 0;
		while (true) {
			this.list = new ArrayList<String>();
			synchronized (br) {
				try {
					while ((line = br.readLine()) != null) {
						if (count >=0) {
							list.add(line);
							count++;
						} else {
							list.add(line);
							count = 0;
							break;
						}
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			try {
				Thread.sleep(1000);
				display(this.list);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (line == null)
				break;
		}

	}

	public void display(List<String> list) {
		for (String str : list) {
			System.out.println(str);
		}

	}

}