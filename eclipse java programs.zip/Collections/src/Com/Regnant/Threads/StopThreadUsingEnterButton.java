package Com.Regnant.Threads;

import java.io.IOException;

public class StopThreadUsingEnterButton {

	public static void main(String[] args) {
		Mythread1 obj=new Mythread1();
		Thread t1=new Thread(obj);
		t1.start();
		try {
			System.in.read();
			obj.stop=true;
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
	}

}
class Mythread1 extends Thread{
	
	boolean stop =false;
	@Override
	public void run() {
		for (int i = 0; i < 100000; i++) {
			System.out.println(i);
			if(stop) {
				return;
			}
		}
		
		
		
	}
	
}