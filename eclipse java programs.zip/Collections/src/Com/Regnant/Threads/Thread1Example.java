package Com.Regnant.Threads;

public class Thread1Example {

	public static void main(String[] args) {
		Thread t1 = new Thread(new Put50());
		Thread t2 = new Thread(new Put100());
		t1.start();
		try {
			Thread.sleep(1000);

		} catch (Exception e) {
			e.printStackTrace();
		}
		t2.start();

	}

}

class Put50 implements Runnable {

	@Override
	public void run() {
		for (int i = 0; i < 5; i++) {
			System.out.println(i + " ");
			try {
				Thread.sleep(1000);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}

class Put100 implements Runnable {

	@Override
	public void run() {
		for (int i = 5; i <= 10; i++) {
			System.out.println(i + " ");
			try {
				Thread.sleep(1000);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

}