package Com.Regnant.Threads;

import java.io.*;

public class Stream2 implements Runnable {

	// public static void main(String[] args) throws IOException {
	public void run() {
		String source = "F:\\Intro.txt";
		String dest = "F:\\Out2.txt";
		// File f = new File(source);

		FileInputStream fin = null;
		try {
			fin = new FileInputStream(source);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		BufferedReader in = new BufferedReader(new InputStreamReader(fin));

		FileWriter fw = null;
		try {
			fw = new FileWriter(dest, true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedWriter out = new BufferedWriter(fw);

		String line = null;
		try {
			while ((line = in.readLine()) != null) {
				out.write(line);
				// out.newLine();
			}
			in.close();
			out.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
