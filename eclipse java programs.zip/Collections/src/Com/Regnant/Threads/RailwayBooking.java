package Com.Regnant.Threads;

public class RailwayBooking {

	public static void main(String[] args) {

		Rail obj=new Rail(5);
		Thread t1=new Thread(obj);
		Thread t2=new Thread(obj);
		t1.setName("heman");
		t2.setName("kumar");
		t1.start();
		t2.start();
		
		
	}

}

class Rail implements Runnable {

	int available = 5;
	int wanted;
Rail(int i){
	wanted=i;
}
	
	
	@Override
	public void run() {

		System.out.println("Avaialable berths are :  " + available);
		if (available >= wanted) {
			String name = Thread.currentThread().getName();
			System.out.println(wanted + " Berths reserved for : " + name);
			try {
				Thread.sleep(2000);
				available=available-wanted;
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} else {
			System.out.println("Sorry !!!! No Berths available :( :( :( :(");
		}

	}

}