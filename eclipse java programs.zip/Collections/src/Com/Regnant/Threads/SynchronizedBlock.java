package Com.Regnant.Threads;

public class SynchronizedBlock {
	public static int count1 = 10;
	public static int count2 = 15;

	public static Object obj1 = new Object();
	public static Object obj2 = new Object();

	public static void add() {
		synchronized (obj1) {
			count1++;
		}
	}

	public static void addagain() {
		synchronized (obj2) {
			count2++;
		}

	}

	public static void compute() {
		add();
		addagain();
	}

	public static void main(String[] args) {
		Thread t1 = new Thread(new Runnable() {

			@Override
			public void run() {
				for (int i = 0; i < 100; i++) {
					compute();
				}
			}
		});
		Thread t2 = new Thread(new Runnable() {

			@Override
			public void run() {
				for (int i = 0; i < 100; i++) {
					compute();
				}
			}
		});

		t1.start();
		t2.start();
		try {
			t1.join();
			t2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("count1 is : " + count1 + "  count2 is : " + count2);
	}

}
