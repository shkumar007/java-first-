package Com.Regnant.Threads;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Vector;

public class SynchronizedBlock2 {

	public static void main(String[] args) {
		Process p = new Process();
		Thread t1 = new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					p.adding();
				} catch (Exception e) {
					e.printStackTrace();
				}

			}

		});

		Thread t2 = new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					p.removing();
				} catch (Exception e) {
					e.printStackTrace();
				}

			}

		});
		t1.start();
		t2.start();
	}

}

class Process {
	int End = 5;
	int start = 0;
	Vector<Integer> list = new Vector<>();
	int value = 0;
	public final Object obj = new Object();
	Scanner sc = new Scanner(System.in);
	

	public void adding() {

		synchronized (obj) {

			while (true) {

				if (list.size() == End) {
					System.out.println("hi Boss it's full wait a moment to remove !!!!");
					try {
						obj.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				} else {
					//System.out.println("pls enter value to add into list : ");
					//m = sc.nextLine();
					System.out.println("Adding value into list : " + value);
					list.add(value);
					value++;
					obj.notify();
				}
				/*
				 * try { Thread.sleep(1000); } catch (InterruptedException e) {
				 * e.printStackTrace(); }
				 */
			}

		}
	}

	public void removing() {

		synchronized (obj) {

			while (true) {
				value--;
				if (list.size() == start) {
					System.out.println("hi Boss it's Empty wait a moment to add !!!!");
					try {
						obj.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				} else {
					System.out.println("removing value from list : " + list.remove(--End));
					 obj.notify();

				}
				/*
				 * try { Thread.sleep(1000); } catch (InterruptedException e) {
				 * e.printStackTrace(); }
				 */
			}

		}
	}
}