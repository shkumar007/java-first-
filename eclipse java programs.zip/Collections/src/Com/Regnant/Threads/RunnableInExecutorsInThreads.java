package Com.Regnant.Threads;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RunnableInExecutorsInThreads {

	public static void main(String[] args) {

 		ExecutorService es= Executors.newFixedThreadPool(3);
 		
 		for (int i = 0; i < 10; i++) {
			es.execute(new Shop());
		}
		es.shutdown();
	}

}

class Shop implements Runnable {

	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.print(i+" ");

		}
	}

}

