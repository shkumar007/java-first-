package Com.Regnant.Threads;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CopyFileFromOneToOtherUsingThread {
	public static void main(String[] args) {
		Thread t1 = new Thread(new One1());
		t1.start();

	}
}

class One1 implements Runnable {
	static BufferedReader br = null;
	 BufferedWriter ooo;
	public List<String> li = null;
	static {
		try {
			br = new BufferedReader(new FileReader("F:\\package2\\One.txt"));
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();

		}
	}

	@Override
	public void run() {
		
		try {
			ooo = new BufferedWriter(new FileWriter(new File("F:\\package2\\Three.txt")));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		String line = null;
		this.li = new ArrayList<>();
		
		synchronized (br) {

			try {
				while ((line = br.readLine()) != null) {
					li.add(line);

				}
			} catch (IOException e) {
				e.printStackTrace();
			}

		}

			for (Iterator iterator = li.iterator(); iterator.hasNext();) {
				String string = (String) iterator.next();
				System.out.println(string);
				
				string =string +System.getProperty("line seperator");
				try {
					ooo.write(string);
				} catch (IOException e) {
					e.printStackTrace();
				}
		}

	}

}
