package Com.Regnant.Threads;

import java.io.FileReader;
import java.io.IOException;

public class ReadingFileUsingThread {
	public static void main(String[] args) {
		Thread t1 = new Thread(new A());
		Thread t2 = new Thread(new B());
		t1.start();

		t2.start();

	}
}

class A implements Runnable {

	@Override
	public void run() {
		int count = 0,n=0;
		try {
			FileReader fin = new FileReader(("F:\\package2\\ONE.txt"));
			int i;
			while ((i = fin.read()) != -1) {
				if (count < 15) {
					System.out.print((char) i);
					count = count + 1;
					n=n+1;
				} else {
					break;
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}

class B implements Runnable {

	@Override
	public void run() {
		int count=16;
		try {
			FileReader fin = new FileReader("F:\\package2\\ONE.txt");
			int i;
			while ((i = fin.read()) != -1) {

				if(count>15) {
				System.out.print((char) i);
				}
				else
				{
					break;
				}
				}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
