package Com.Regnant.Threads;

public class VolatileKeyword 
{

	public static void main(String[] args) 
	{
		Work m = new Work();
		Thread t1 = new Thread(m);
		t1.start();
		try {
			Thread.sleep(500);
			} 
		catch (InterruptedException e) 
			{
			e.printStackTrace();
			}

		m.setIsterminated(false);
		System.out.println("finished------->");

	}

}

class Work implements Runnable 
{
	private boolean isterminated = true;

	@Override
	public void run() 
	{

		while (isterminated) 
		{
			System.out.println("hello mama----->");
			try
			{
				Thread.sleep(1000);
			} catch (InterruptedException e) 
			{
				e.printStackTrace();
			}
		}

	}

	public boolean isIsterminated() 
	{
		return isterminated;
	}

	public void setIsterminated(boolean isterminated)
	{
		this.isterminated = isterminated;
	}

}