package Com.Regnant.Threads;

import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SynchronizedMethodInMultiThreading {

	public static void main(String[] args) {
		A1 obj = new A1();
		Thread t1 = new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					obj.hi();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		});
		Thread t2 = new Thread(new Runnable() {

			@Override
			public void run() {
				try {
					obj.Hello();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		});

		try {
			t1.start();
			// t1.join();
			t2.start();
			t2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}

class A1 {

	Lock l = new ReentrantLock();
Condition con=l.newCondition();
	public void hi() throws InterruptedException {
		l.lock();
		System.out.println("we are in Hi method ...");
		con.await();
		System.out.println("Again in Hi method only");
		l.unlock();
	}

	public void Hello() throws InterruptedException {
		l.lock();
		Thread.sleep(1000);
		System.out.println("we are in Hello method ...");
		// notify();
		//notifyAll();
		con.signal();
		Thread.sleep(500);
		l.unlock();
	}
}