package Com.Regnant.Threads;

public class Example5printingValueFor1Second {
	public static void main(String[] args) {

		Worker obj = new Worker();
		Thread t1 = new Thread(obj);
		t1.start();
		try {
			Thread.sleep(1000);
		} catch (Exception e) {
			e.printStackTrace();
		}
		obj.setTerminated(true);
		System.out.println("finished job!!!!");
 
	}
}

class Worker implements Runnable {
	private boolean isTerminated = false;
	int count = 0;

	@Override
	public void run() {
		while (!isTerminated) {
			System.out.println("hello robo from workers :" + count++);

			try {
				Thread.sleep(100);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}

	public boolean isTerminated() {
		return isTerminated;

	}

	public void setTerminated(boolean isTerminated) {
		this.isTerminated = isTerminated;
	}

}