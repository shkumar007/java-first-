package Com.Regnant.Threads;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CopyFromListToAnotherUsingThreads {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		Num1 obj = new Num1();
		obj.load();

		ExecutorService es = Executors.newFixedThreadPool(2);
		Future<Integer> f1 = es.submit(new Sum1(obj.li, 0, 1000, obj.copy));
		Future<Integer> f2 = es.submit(new Sum1(obj.li, 1000, 2000, obj.copy));
		Future<Integer> f3 = es.submit(new Sum1(obj.li, 2000, 3000, obj.copy));
		Future<Integer> f4 = es.submit(new Sum1(obj.li, 3000, 4000, obj.copy));
		Future<Integer> f5 = es.submit(new Sum1(obj.li, 4000, 5000, obj.copy));
		Future<Integer> f6 = es.submit(new Sum1(obj.li, 5000, 6000, obj.copy));
		Future<Integer> f7 = es.submit(new Sum1(obj.li, 6000, 7000, obj.copy));
		Future<Integer> f8 = es.submit(new Sum1(obj.li, 7000, 8000, obj.copy));
		Future<Integer> f9 = es.submit(new Sum1(obj.li, 8000, 9000, obj.copy));
		Future<Integer> f10 = es.submit(new Sum1(obj.li, 9000, 10000, obj.copy));
		Integer s1 = f1.get();
		Integer s2 = f2.get();
		Integer s3 = f3.get();
		Integer s4 = f4.get();
		Integer s5 = f5.get();
		Integer s6 = f6.get();
		Integer s7 = f7.get();
		Integer s8 = f8.get();
		Integer s9 = f9.get();
		Integer s10 = f10.get();

		System.out.println("Sum is : " + (s1 + s2 + s3 + s4 + s5 + s6 + s7 + s8 + s9 + s10));

	}

}

class Num1 {
	List<Integer> li = new ArrayList<Integer>();
	List<Integer> copy = new ArrayList<Integer>();

	public void load() {
		for (int i = 0; i <= 10000; i++) {

			li.add(i);
		}
	}
}

class Sum1 implements Callable<Integer> {
	List<Integer> li;
	List<Integer> copy;
	int start;
	int end;

	Sum1(List<Integer> li, int start, int end, List<Integer> copy) {
		this.li = li;
		this.start = start;
		this.end = end;
		this.copy = copy;

	}

	@Override
	public Integer call() {

		int sum = 0;

		for (int i = start; i < end; i++) {
			sum = sum + li.get(i);
			synchronized (Num1.class) {
				copy.add(i);
			}
		}
		return sum;
	}

}