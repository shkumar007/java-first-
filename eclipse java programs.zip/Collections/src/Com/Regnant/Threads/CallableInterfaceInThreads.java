package Com.Regnant.Threads;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class CallableInterfaceInThreads {

	public static void main(String[] args) throws InterruptedException, ExecutionException {
		long startTime = System.currentTimeMillis();
		Num obj = new Num();
		obj.load();
		
		/*
		
		1.) ExecutorService es = Executors.newCachedThreadPool();
		 *  	- going to return an executorService that can dynamically
		 *  		reuse threads
		 *		- before starting a job -> it going to check whether there are any threads that
		 *			finished the job...reuse them
		 *		- if there are no waiting threads -> it is going to create another one 
		 *		- good for the processor ... effective solution !!!
		 *
		 *	2.) ExecutorService es = Executors.newFixedThreadPool(N);
		 *		- maximize the number of threads
		 *		- if we want to start a job -> if all the threads are busy, we have to wait for one
		 *			to terminate
		 *
		 *	3.) ExecutorService es = Executors.newSingleThreadExecutor();
		 *		It uses a single thread for the job
		 *
		 *		execute() -> runnable + callable
		 *		submit() -> runnable
		*/

		/***
		 * to find no of cores present in the system
		 */
		/*
		 * int cores = Runtime.getRuntime().availableProcessors();
		 * System.out.println(cores);
		 */
		Future<Integer> ar = null;
		ExecutorService es = Executors.newCachedThreadPool();
		List<Future<Integer>> aa = new ArrayList();
		int start = 0, end = 1000;
		for (int i = 0; i < 10; i++) {

			ar = es.submit(new Sum(obj.li, start, end));
			aa.add(ar);

			start = end;
			end = end + 1000;

		}

		int sum = 0;

		for (Future<Integer> future : aa) {
			sum = sum + future.get();
		}

		System.out.println(sum);
		
/*		ExecutorService es = Executors.newFixedThreadPool(2);
		Future<Integer> f1 = es.submit(new Sum(obj.li, 0, 1000));
		Future<Integer> f2 = es.submit(new Sum(obj.li, 1000, 2000));
		Future<Integer> f3 = es.submit(new Sum(obj.li, 2000, 3000));
		Future<Integer> f4 = es.submit(new Sum(obj.li, 3000, 4000));
		Future<Integer> f5 = es.submit(new Sum(obj.li, 4000, 5000));
		Future<Integer> f6 = es.submit(new Sum(obj.li, 5000, 6000));
		Future<Integer> f7 = es.submit(new Sum(obj.li, 6000, 7000));
		Future<Integer> f8 = es.submit(new Sum(obj.li, 7000, 8000));
		Future<Integer> f9 = es.submit(new Sum(obj.li, 8000, 9000));
		Future<Integer> f10 = es.submit(new Sum(obj.li, 9000, 10000));
		Integer s1 = f1.get();
		Integer s2 = f2.get();
		Integer s3 = f3.get();
		Integer s4 = f4.get();
		Integer s5 = f5.get();
		Integer s6 = f6.get();
		Integer s7 = f7.get();
		Integer s8 = f8.get();
		Integer s9 = f9.get();
		Integer s10 = f10.get();

		System.out.println("Sum is : " + (s1 + s2 + s3 + s4 + s5 + s6 + s7 + s8 + s9 + s10));
*/
		long stopTime = System.currentTimeMillis();
		long elapsedTime = stopTime - startTime;
		System.out.println(elapsedTime);

	}

}

class Num {
	List<Integer> li = new ArrayList<Integer>();

	public void load() {
		for (int i = 0; i < 10000; i++) {
			li.add(i);
		}
	}
}

class Sum implements Callable<Integer> {
	List<Integer> li;
	int start;
	int end;

	Sum(List<Integer> li, int start, int end) {
		this.li = li;
		this.start = start;
		this.end = end;

	}

	@Override
	public Integer call() throws Exception {
		int sum = 0;

		for (int i = start; i < end; i++) {
			sum = sum + li.get(i);
		}

		return sum;
	}

}