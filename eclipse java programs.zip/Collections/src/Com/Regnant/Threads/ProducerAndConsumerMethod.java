package Com.Regnant.Threads;

class Buffer {
	int num;

	public int getNum() {
		return num;
	}

	public void setNum(int num) {

		this.num = num;
	}

}

class Producer implements Runnable {
	Buffer b;

	public Producer(Buffer b) {
		this.b = b;
	}

	@Override
	public void run() {
		int j = 0;

		if (true) {
			System.out.println("set : " + j);

			b.setNum(j++);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}

class Consumer implements Runnable {
	Buffer b;

	public Consumer(Buffer b) {
		this.b = b;
	}

	@Override
	public void run() {
		if (true) {
			System.out.println("get : " + b.getNum());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}

public class ProducerAndConsumerMethod {

	public static void main(String[] args) {

		Buffer obj = new Buffer();
		Thread t1 = new Thread(new Producer(obj));
		Thread t2 = new Thread(new Consumer(obj));

		t1.start();
		t2.start();

	}

}
