package Com.Regnant.Threads;

public class ThreadsPracticeRough {

	public static void main(String[] args) {

		Thread t1=new Thread(new One2());
		t1.start();
		t1.run();
		
	}

}

class One2 implements Runnable {

	@Override
	public void run() {

		System.out.println("run method::::::::::::::::  "+Thread.currentThread().getName());
		
	}

}
