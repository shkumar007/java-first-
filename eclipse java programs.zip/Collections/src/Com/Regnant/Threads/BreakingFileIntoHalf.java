package Com.Regnant.Threads;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class Eng implements Runnable {
	public void run() {
		try {
			FileReader fr = new FileReader("F:\\package2\\ONE.txt");
			int l, k = 0;
			List<Integer> i = new ArrayList<Integer>();
			while ((l = fr.read()) != -1) {
				i.add(l);
				k++;
			}
			for (int j = 0; j < k / 2; j++) {
				System.out.print((char) (int) (i.get(j)));
			}
			fr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

class Tel implements Runnable {
	public void run() {
		try {
			FileReader fr = new FileReader("F:\\package2\\ONE.txt");
			int l, k = 0;
			List<Integer> i = new ArrayList<Integer>();
			while ((l = fr.read()) != -1) {
				i.add(l);
				k++;
			}
			for (int j = k / 2; j < k; j++) {
				System.out.print((char) (int) (i.get(j)));
			}

			fr.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

public class BreakingFileIntoHalf {

	public static void main(String[] args) {

		Thread e = new Thread(new Tel());
		Thread t = new Thread(new Eng());
		e.start();
		t.start();

	}

}
