package Com.Regnant.Threads;

class Runner1 extends Thread {

	@Override
	public void run() {

		try {
			for (int i = 0; i < 10; ++i) {
				System.out.println("Runner1: " + i);
				Thread.sleep(100);

			}

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}

class Runner2 extends Thread {

	@Override
	public synchronized void run() {

		try {
			for (int i = 0; i < 20; ++i) {
				System.out.println("Runner2: " + i);

				Thread.sleep(100);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}

public class Example4 {

	public static void main(String[] args) {

		Thread t1 = new Thread(new Runner1());
		Thread t2 = new Thread(new Runner2());

//		Runner1 t1 = new Runner1();
//		Runner2 t2 = new Runner2();

		try {
			t1.start();
			t1.join();
			t2.start();
			t2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("Finished the tasks...");
	}
}
