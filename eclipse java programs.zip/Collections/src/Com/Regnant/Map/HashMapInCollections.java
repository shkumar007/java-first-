package Com.Regnant.Map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class HashMapInCollections {

	public static void main(String[] args) {

		HashMap<Integer, String> hm = new HashMap<Integer, String>();

		hm.put(1, "value1");
		hm.put(3, "value3");
		hm.putIfAbsent(4, "value3");
		for (Map.Entry l : hm.entrySet()) {
			System.out.println(l.getKey() + ":::: " + l.getValue());
		}

	}

}
