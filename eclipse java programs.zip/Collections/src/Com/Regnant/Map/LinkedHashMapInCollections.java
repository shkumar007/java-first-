package Com.Regnant.Map;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class LinkedHashMapInCollections {

	public static void main(String[] args) {

		Map<Integer, List<Integer>> mm = new HashMap();
		List<Integer> one = new ArrayList<>(6);
		one.add(3);
		one.add(5);
		one.add(0);
		one.add(6);
		one.add(7);
		List<Integer> two = new ArrayList<>(6);
		two.add(3);
		two.add(5);
		two.add(0);
		two.add(6);
		two.add(7);
		two.add(1);
		mm.put(1, one);
		mm.put(2, two);
		int integer = 0;
		
		integer = total(mm, one, integer);
		
		System.out.println(integer);
		
		integer = total(mm, two, integer);
		
		System.out.println(integer);
		
	}

	public static int total(Map<Integer, List<Integer>> mm, List<Integer> one, int integer) {
		for (Iterator iterator = one.iterator(); iterator.hasNext();) {
			 integer += (Integer) iterator.next();
			
		}
		/*for (Map.Entry l : mm.entrySet()) {
			System.out.println("over : "+l.getKey() + " Score ball by ball : " + l.getValue()+"total score of over is : "+integer);
			
		}*/
		return integer;
	}

}
