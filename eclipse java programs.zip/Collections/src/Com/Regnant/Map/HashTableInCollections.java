package Com.Regnant.Map;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;
import java.util.Scanner;

public class HashTableInCollections {

	public static void main(String[] args) {

		Hashtable<String, Integer> arr = new Hashtable();
		arr.put("Gambir".toUpperCase().trim(), 183);
		arr.put("DHAWAN".toUpperCase().trim(), 122);
		arr.put("Rohit".toUpperCase().trim(), 33);
		arr.put("virat".toUpperCase().trim(), 55);
		arr.put("rahane".toUpperCase().trim(), 99);
		arr.put("Dhoni".toUpperCase().trim(), 133);
		arr.put("ashwin".toUpperCase().trim(), 33);
		arr.put("Jadeja".toUpperCase().trim(), 15);
		arr.put("Ishant".toUpperCase().trim(), 0);
		arr.put("Umesh".toUpperCase().trim(), 0);
		System.out.println("players in team are : ");
		/***
		 * key -------value based on key we are finding value
		 * 
		 */
		/*
		 * Enumeration e=arr.keys(); 
		 * while (e.hasMoreElements())
		 *  {
		 * System.out.println(e.nextElement()); 
		 * }
		 * 
		 * 
		 * System.out.println("pls enter player name : ");
		 *  Scanner sc=newScanner(System.in); 
		 *  String name=sc.nextLine().trim().toUpperCase(); 
		 *  int score=arr.get(name); 
		 *  System.out.println(name +" scored  : "+score);
		 */
		/***
		 * value -------key based on value we are finding key
		 * 
		 */

		/*
		 * Collection<Integer> e=arr.values(); System.out.println(e);
		 * 
		 * System.out.println("pls enter Score : ");
		 *  Scanner sc=new Scanner(System.in);
		 * int x=sc.nextInt(); 
		 * for (Entry entry : arr.entrySet()) 
		 * {
		 *  if(entry.getValue().equals(x))
		 *  {
		 *   System.out.println(entry.getKey());
		 *    }
		 *  }
		 */

		
		int x = 122;
		
		for (Entry mmm : arr.entrySet()) {
			if (mmm.getValue().equals(x))
				System.out.println(mmm.getKey());
		}

	}

}
