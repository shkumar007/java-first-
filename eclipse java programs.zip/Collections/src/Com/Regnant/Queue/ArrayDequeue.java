package Com.Regnant.Queue;

import java.util.ArrayDeque;
import java.util.Deque;

public class ArrayDequeue {

	public static void main(String[] args) {

		
		Deque<String> ar=new ArrayDeque();
		
		ar.add("hello");
		ar.add("robo");
		ar.add("2.0");
		
		System.out.println(ar);
	}

}
