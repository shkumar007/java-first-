package Com.Regnant.Queue;

import java.util.LinkedList;
import java.util.Queue;

public class PriorityQueueIn {

	public static void main(String[] args) {

		Queue<String> m = new LinkedList<String>();
		m.add("mama");
		m.add("akkada");
		m.add("pulamma");
		m.add("akkada");

		m.remove("akkada");

		System.out.println("----------------");
		Object[] b = m.toArray();
		for (Object object : b) {
			System.out.print(object + " ");
		}

	}

}
