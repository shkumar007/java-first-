package Com.Regnant.Practise;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class SortByCompareMethod {

	public static void main(String[] args) {

		List<Student12> ar = new ArrayList();

		ar.add(new Student12(2, "kkkk"));
		ar.add(new Student12(1, "kk"));
		ar.add(new Student12(3, "k"));

		Comparator<Student12> ccc = new Comparator<Student12>() {

			@Override
			public int compare(Student12 o1, Student12 o2) {
				if (o1.getId() > o2.getId())
					return 1;
				else if (o1.getId() < o2.getId())
					return -1;
				else
					return 0;
			}

		};

		//Collections.sort(ar);

		for (Student12 integer : ar) {
			System.out.print(integer + " ");
		}

	}

}
