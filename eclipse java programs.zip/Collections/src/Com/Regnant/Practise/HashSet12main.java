package Com.Regnant.Practise;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class HashSet12main {

	public static void main(String[] args) {

		Student12 s1 = new Student12(3, "heman");
		Student12 s2 = new Student12(2, "Kumar");
		Student12 s3 = new Student12(1, "Kumar");
		HashSet<Student12> n = new HashSet<>();

		n.add(s1);
		n.add(s2);
		n.add(s3);

		System.out.println(n);

	}

}

/*
 * for(Map.Entry<Integer, Student12> mn:n.entrySet()) { Student12
 * b=mn.getValue(); System.out.println(mn.getKey()+"/////"+"id is : "+ b.id +
 * " name is : "+ b.name ); }
 */
