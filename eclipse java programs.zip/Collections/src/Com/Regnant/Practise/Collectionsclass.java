package Com.Regnant.Practise;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Collectionsclass {

	public static void main(String[] args) {

		List<Integer> ar = new ArrayList<Integer>();
		ar.add(10);
		ar.add(20);
		ar.add(5);
		ar.add(2);
		ar.add(1);
		ar.add(-1);
		ar.add(22);
		ar.add(0);
		Collections.sort(ar,Collections.reverseOrder());
		System.out.println(ar);
		
		
		
	}

}
