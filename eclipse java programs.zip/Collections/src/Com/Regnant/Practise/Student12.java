package Com.Regnant.Practise;

import java.util.Objects;

public class Student12 {

	private int id;

	private String name;

	public Student12(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj) {
			return true;
		}

		Student12 m = (Student12) obj;

		return id == m.id;

	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return Objects.hash(id);
	}

	@Override
	public String toString() {
		
		return "Student { id : " + id + "  , name :  " + name + "}";
	}

}
