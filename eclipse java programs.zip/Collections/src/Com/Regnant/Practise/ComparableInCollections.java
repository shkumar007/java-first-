package Com.Regnant.Practise;

import java.util.ArrayList;
import java.util.Scanner;

public class ComparableInCollections {

	public static void main(String[] args) {

		ArrayList<EmployeeInCollections> ar = new ArrayList<EmployeeInCollections>();
		ar.add(new EmployeeInCollections(2, "222"));
		ar.add(new EmployeeInCollections(4, "444"));
		ar.add(new EmployeeInCollections(1, "111"));
		ar.add(new EmployeeInCollections(3, "333"));
		ar.add(new EmployeeInCollections(3, "333"));

		Scanner sc = new Scanner(System.in);

		System.out.println("pls enter your option : ");
		System.out.println("1.select * from table");
		System.out.println("2.select * from where id =");
		int name = sc.nextInt();

		switch (name) {

		case 1:
			for (EmployeeInCollections employeeInCollections : ar) {
				System.out.println(employeeInCollections);
			}

			break;

		case 2:

			System.out.println("pls enter id");
			int id1 = sc.nextInt();
			EmployeeInCollections obj = null;
			for (int i = 0; i < ar.size(); i++) {
				obj = ar.get(i);

				if (obj.getId() == id1) {
					System.out.println(obj);
				}

			}

			break;

		}
		sc.close();

	}

}
