package Com.Regnant.Practise;


public class EmployeeInCollections implements Comparable<EmployeeInCollections> {

	private int id;
	private String name;

	public EmployeeInCollections(int l, String string) {

		this.id = l;
		this.name = string;

	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Employee { id : " + id + "  , name :  " + name +" } ";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
//this method for sorting an list in arraylist
	
	@Override
	public int compareTo(EmployeeInCollections o) {

		return Integer.compare(this.getId(), o.id);
		// return this.getName().compareTo(o.getName());
	}

}
