package Com.Regnant.Practise;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Araylist12 {

	public static void main(String[] args) {

		List<Student12>aaa=new ArrayList<>();
		aaa.add(new Student12(2, "bbbbbbb"));
		aaa.add(new Student12(1, "aaaaaaa"));
		aaa.add(new Student12(3, "ccccccc"));
	
		
			for (Student12 student12 : aaa) {
				System.out.println(student12);

			}

		

		
	}
	
	

}
