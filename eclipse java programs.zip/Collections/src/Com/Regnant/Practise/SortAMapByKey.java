package Com.Regnant.Practise;

import java.util.Collections;
import java.util.HashMap;
import java.util.TreeMap;

public class SortAMapByKey {

	public static void main(String[] args) {

		HashMap<Integer, String> ar = new HashMap();
		ar.put(5, "babu");
		ar.put(4, "ra ");
		ar.put(2, "pentaiiah");
		ar.put(1, "hello");
		ar.put(6, "phone lift chai");
		ar.put(3, "akkada");

		TreeMap<Integer,String> arr=new TreeMap(ar);
		
		System.out.println(arr);
	}

}
