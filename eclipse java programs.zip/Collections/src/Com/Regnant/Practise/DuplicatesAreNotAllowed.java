package Com.Regnant.Practise;

import java.util.ArrayList;
import java.util.HashMap;

public class DuplicatesAreNotAllowed {

	public static void main(String[] args) {

		HashMap<Integer, String> a = new HashMap();

		a.put(1, "a");
		a.put(2, "b");
		a.put(3, "c");
		HashMap<Integer, String> ar = new HashMap();

		ar.put(4, "a");
		ar.put(5, "b");
		ar.put(6, "c");

		HashMap<Integer, String> arr = new HashMap();

		arr.put(1, "a");
		arr.put(2, "b");
		arr.put(3, "c");
		arr.put(4, "c");

		System.out.println(new ArrayList(a.values()).equals(new ArrayList(ar.values())));
		System.out.println(new ArrayList(a.values()).equals(new ArrayList(arr.values())));

	}

}
