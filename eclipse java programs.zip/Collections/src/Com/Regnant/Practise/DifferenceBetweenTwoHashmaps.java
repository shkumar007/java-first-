package Com.Regnant.Practise;

import java.util.HashMap;
import java.util.HashSet;

public class DifferenceBetweenTwoHashmaps {

	public static void main(String[] args) {
		HashMap<Integer, String> ar = new HashMap();

		ar.put(1, "a");
		ar.put(2, "b");
		ar.put(3, "c");

		HashMap<Integer, String> arr = new HashMap();

		arr.put(1, "a");
		arr.put(2, "b");
		arr.put(3, "c");
		arr.put(4, "d");

		HashSet<Integer> a = new HashSet<>(ar.keySet());
		a.addAll(arr.keySet());
		a.removeAll(ar.keySet());
		System.out.println(a);

	}

}
