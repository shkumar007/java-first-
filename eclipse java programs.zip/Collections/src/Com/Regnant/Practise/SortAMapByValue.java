package Com.Regnant.Practise;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class SortAMapByValue {

	public static void main(String[] args) {
		HashMap<Integer, String> ar = new HashMap();
		ar.put(5, "babu");
		ar.put(4, "ra ");
		ar.put(2, "pentaiiah");
		ar.put(1, "hello");
		ar.put(6, "phone lift chai");
		ar.put(3, "akkada");
		LinkedHashMap<Integer, String> arr = new LinkedHashMap<>();
		
		
		ar.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEachOrdered(x -> arr.put(x.getKey(), x.getValue()));
		
		System.out.println(arr);
		
		
		
		
		
	}

}
