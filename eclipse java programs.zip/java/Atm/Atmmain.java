package Atm;

import java.util.Scanner;

public class Atmmain {

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("pls select options ");
		System.out.println("1.withdraw ");
		System.out.println("2.ministatement ");
		
		int x=sc.nextInt();
		switch(x) {
		
		case 1 : Withdraw obj=new Withdraw();
		         obj.a();
		         break;
	/*//	case 2 : Ministatement obj1= new Ministatement();
		         obj1.mini();
		         break;
		         
		         default:System.out.println("see the options and type stupid");
		
		*/
		}
		
		

	}

}
