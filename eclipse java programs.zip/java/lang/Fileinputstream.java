package lang;
import java.io.FileInputStream;
//import java.io.FileNotFoundException;
import java.io.IOException;
public class Fileinputstream {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		
		FileInputStream fin=new FileInputStream("C:/Users/new/Desktop/hai.pdf");
		int x;
		while ((x=fin.read())!=-1) {
			System.out.print((char)x);
		}
		fin.close();
		System.out.println();
		System.out.println("oooooooh");
		
	}

}
