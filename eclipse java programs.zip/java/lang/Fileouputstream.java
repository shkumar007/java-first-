package lang;
import java.io.BufferedOutputStream;
//import java.io.FileNotFoundException;
import java.io.FileOutputStream;

import java.io.IOException;
import java.util.Scanner;

public class Fileouputstream {

	public static void main(String[] args)throws IOException {
				
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the data : ");
		String inputstring=sc.nextLine();
		/*
		System.out.println("enter integer values ");
		int x=sc.nextInt();*/
		
		//FileOutputStream fout=new FileOutputStream("F:\\package2\\ONE.txt");
		BufferedOutputStream ooo=new BufferedOutputStream(new FileOutputStream("F:\\package2\\ONE.txt"));
		ooo.write(inputstring.getBytes());
		
		
		//fout.write(x);
				
		sc.close();
		ooo.close();
		System.out.println("Success :) :) :) :)");
	}

}
